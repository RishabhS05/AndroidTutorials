//
//  main.swift
//  Application7
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1(values: String...) {
    print(values)
    print("type of values: \(type(of: values))")
}

//function1(values: "test1", "test2", "test3")

func add(_ values: Int...) {
    var sum = 0
    for value in values {
        sum += value
    }
    
    print("sum = \(sum)")
}

add(1, 2)
add(1, 2, 3, 4, 5)
add(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)


func function2(_ param: Int) {
    print("inside function2")
    print("param = \(param)")
}

function2(10)
