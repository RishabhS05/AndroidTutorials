//
//  main.swift
//  Application8
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation



// () -> Void
func function1() -> Void {
    print("inside function1")
}

// () -> String
func function2() -> String {
    print("inside function2")
    return "something"
}

// (Int) -> Int
func function3(param: Int) -> Int {
    print("inside function3")
    return 1
}

// (String, String, Int) -> Bool
func function4(name: String, address: String, age: Int) -> Bool {
    print("inside function4")
    return false
}

print("type of function1: \(type(of: function1))")
print("type of function2: \(type(of: function2))")
print("type of function3: \(type(of: function3))")
print("type of function4: \(type(of: function4))")


let num = 10
print("type of num = \(type(of: num))")

let name = "person1"
print("type of name = \(type(of: name))")

let canVote = false
print("type of canVote = \(type(of: canVote))")

let num2: Int = num
let name2: String = name
let canVote2: Bool = canVote

let person = ("person1", "pune", 40)
print("type person: \(type(of: person))")

let person2: (String, String, Int) = person

let numbers = [1, 2, 3, 4, 5]

let numbers2: [Int] = numbers
