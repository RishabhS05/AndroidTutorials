//
//  main.swift
//  Application4
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    // cat: a pet animal
    // mouse: a device used with computer
    
    // implicit (type inference)
    let dictionary = [
        "cat": "a pet animal",
        "mouse": "a device used with computer"
    ]
    
    print("type of dictionary: \(type(of: dictionary))")
    print("dictionary: \(dictionary)")
}

//function1()

func function2() {
    // explicit (type annotation)
    let dictionary1 : Dictionary<String, String> = [
        "cat": "a pet animal",
        "mouse": "a device used with computer"
    ]
    
    // explicit (type annotation)
    let dictionary2 : [String: String] = [
        "cat": "a pet animal",
        "mouse": "a device used with computer"
    ]
}

//function2()

func function3() {
    var dictionary1: Dictionary<String, String> = [:]
    var dictionary2: [String: String] = [:]
    
    var dictionary3: Dictionary<String, String> = Dictionary<String, String>()
    var dictionary4: [String: String] = Dictionary<String, String>()
}

func function4() {
    var dictionary = [
        "cat": "a pet animal",
        "mouse": "a device used with computer"
    ]
    
    // get all the keys
    print("keys: \(dictionary.keys)")
    
    // get all the values
    print("values: \(dictionary.values)")
    
    // get a value by key
    if let value = dictionary["cat"] {
        print("cat is : \(value)")
    } else {
        print("cat is not in dictionary")
    }
    
    if let value = dictionary["keyboard"] {
        print("keyboard is : \(value)")
    } else {
        print("keyboard is not in dictionary")
    }
    
    // add a new key-value pair
    dictionary["keyboard"] = "an input device"
    if let value = dictionary["keyboard"] {
        print("keyboard is : \(value)")
    } else {
        print("keyboard is not in dictionary")
    }
}

function4()
