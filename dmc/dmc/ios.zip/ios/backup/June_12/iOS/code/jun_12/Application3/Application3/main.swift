//
//  main.swift
//  Application3
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    // person info
    let name = "person1"
    let address = "Pune"
    let email = "person1@test.com"
    
    // person info
    let person1  = ["person1", "Pune", "person1@test.com"]
    
    print("name: \(person1[0])")
    print("address: \(person1[1])")
    print("email: \(person1[2])")
}

//function1()


func function2() {
    let person1 = ["person1", "Pune", "person1@test.com"]
    print("type of person1: \(type(of: person1))")
    
    let person2 = ("person1", "Pune", "person1@test.com")
    print("type of person2: \(type(of: person2))")
}

//function2()

func function3() {
    let person1 = ("person1", "Pune", "person1@test.com", 40, true)
    print(person1)
    
    print("name: \(person1.0)")
    print("address: \(person1.1)")
    print("email: \(person1.2)")
    print("age: \(person1.3)")
    
}

//function3()

func function4() {
    // explicit (type annotation)
    let person1: (String, String, String, Int, Bool) =
            ("person1", "Pune", "person1@test.com", 40, true)
    print(person1)
    
    print("name: \(person1.0)")
    print("address: \(person1.1)")
    print("email: \(person1.2)")
    print("age: \(person1.3)")
}

//function4()

func function5() {
    let person1: (name: String, address: String, email: String, age: Int, canVote: Bool) =
        ("person1", "Pune", "person1@test.com", 40, true)
    
//    print("name: \(person1.0)")
//    print("address: \(person1.1)")
//    print("email: \(person1.2)")
//    print("age: \(person1.3)")
//    print("canVote: \(person1.4)")
    
    print("name: \(person1.name)")
    print("address: \(person1.address)")
    print("email: \(person1.email)")
    print("age: \(person1.age)")
    print("canVote: \(person1.canVote)")
}

//function5()


