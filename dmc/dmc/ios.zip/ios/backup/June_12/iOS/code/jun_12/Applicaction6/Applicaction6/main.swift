//
//  main.swift
//  Applicaction6
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

enum Day {
    case Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
}

let day = Day.Monday

switch (day) {
case .Monday:
    print("aah.. the week started again...")
    fallthrough
case .Tuesday:
    print("fine.. will start working")
case .Wednesday:
    print("working... working..")
case .Thursday:
    print("planning for weekend")
case .Friday:
    print("yes.. today is the last day week :) :) :)")
case .Saturday:
    print("enjoying... ")
case .Sunday:
    print("still enjoying... ")
default:
    print("are you kidding me? ")
}
