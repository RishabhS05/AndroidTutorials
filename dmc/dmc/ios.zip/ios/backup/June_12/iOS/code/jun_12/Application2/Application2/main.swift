//
//  main.swift
//  Application2
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    let numbers = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5]
    print(numbers)
    print("type of numbers: \(type(of: numbers))")
    
    let set: Set<Int> = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5]
    print(set)
    print("type of set: \(type(of: set))")
}

//function1()

func function2() {
    let s1: Set<Int> = [1, 2, 3, 4, 5]
    let s2: Set<Int> = [4, 5, 6, 7, 8]
    
    print("union: \(s1.union(s2))")
    print("union: \(s2.union(s1))")
    
    print("intersection: \(s1.intersection(s2))")
    print("intersection: \(s2.intersection(s1))")
    
    print("symmetric differnce: \(s1.symmetricDifference(s2))")
    print("symmetric differnce: \(s2.symmetricDifference(s1))")
    
    print("s1 - s2 = \(s1.subtracting(s2))")
    print("s2 - s1 = \(s2.subtracting(s1))")
}

function2()
