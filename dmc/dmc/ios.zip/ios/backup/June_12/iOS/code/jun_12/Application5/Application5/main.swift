//
//  main.swift
//  Application5
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    let array = [
        [10, 20, 30, 40, 50],
        [60, 70],
        [80, 90, 100, 110, 120, 130, 140],
        [150]
    ]
    
//    print(array)
    for innerArray in array {
        for value in innerArray {
            print(value)
        }
        
        print("--------")
    }
}

//function1()


func function2() {
    let s1: Set<Int> = [10, 20, 30, 40, 50]
    let s2: Set<Int> = [60, 70]
    let s3: Set<Int> = [80, 90, 100, 110, 120, 130, 140]
    let s4: Set<Int> = [150]
    
    let array: [Set<Int>] = [s1, s2, s3, s4]
    
    //    print(array)
    for innerArray in array {
        for value in innerArray {
            print(value)
        }
        
        print("--------")
    }
}

//function2()

func function3() {
    let persons = [
        ("person1", "Pune", 40),
        ("person2", "Karad", 10),
        ("person3", "Satara", 20),
        ("person4", "Mumbai", 30)
    ]
    
//    for person in persons {
//        print("name: \(person.0)")
//        print("address: \(person.1)")
//        print("age: \(person.2)")
//
//        print("---------")
//    }

    for (name, address, age) in persons {
        print("name: \(name)")
        print("address: \(address)")
        print("age: \(age)")

        print("------")
    }
    
}

//function3()

func function4() {
    let persons = [
        ["name": "person1", "address": "pune", "email": "p1@test.com"],
        ["name": "person2", "address": "satara", "email": "p2@test.com"],
        ["name": "person3", "address": "karad", "email": "p3@test.com"],
    ]
    
    for person in persons {
        print("name: \(person["name"]!)")
        print("address: \(person["address"]!)")
        print("email: \(person["email"]!)")
        
        print("------")
    }
}

function4()
