//
//  main.swift
//  Application11
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation


struct Person {
    var name: String
    var address: String
    var age: Int
}

var person1 = Person(name: "person1", address: "Pune", age: 40)
print("name: \(person1.name)")
print("address: \(person1.address)")
print("age: \(person1.age)")

person1.name = "person2"
person1.age = 45
person1.address = "Karad"

print("name: \(person1.name)")
print("address: \(person1.address)")
print("age: \(person1.age)")


