//
//  main.swift
//  Application1
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    // implicit (type inference)
    let array = [1, 2, 3, 4, 5, 5, 6, 6, 6, 7, 8, 9, 9, 10, 10]
    print(array)
    print(type(of: array))
    
    // explicit (type annotation)
    let array1: Array<Int> = [1, 2, 3, 4, 5]
    print(type(of: array1))
    
    let array2: [Int] = [1, 2, 3, 4, 5]
    print(type(of: array2))
    
//    print(array)

//    for..in loop
//    for value in array {
//        print(value)
//    }

//    traditional for loop
//    for index in 0..<array.count {
//        print(array[index])
//    }
    
}

//function1()


func function2() {
    var countries: [String] = ["India", "USA", "UK", "China", "Japan"]
    print(countries)
    
    countries.append("Sri Lanka")
    print(countries)
    
    let country = countries.remove(at: 3)
    print("removed: \(country)")
    print(countries)
    
    print(countries.sorted())
    print(countries)
    
    countries.removeAll()
    print(countries)
}

//function2()

func function3() {
    var arrayInt1: [Int] = []
    var arrayInt2: Array<Int> = []
    
    var arrayInt3: [Int] = Array<Int>()
    var arrayInt4: Array<Int> = Array<Int>()
}
