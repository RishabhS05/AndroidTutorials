//
//  main.swift
//  Application9
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

// (Int) -> Int
func square(num: Int) -> Int {
    return num * num
}

// (Int) -> Int
func cube(num: Int) -> Int {
    return num * num * num
}


// (Int) -> Bool
func isEven(num: Int) -> Bool {
    return num % 2 == 0
}

// (Int) -> Bool
func isOdd(num: Int) -> Bool {
    return num % 2 != 0
}


let num = 100
let num2 = num

// function reference

// implicit
let mySquare = square
print("mysquare type = \(type(of: mySquare))")
print("square: \(mySquare(10))")

// explicit
let myCube: (Int) -> Int = cube
print("myCube type: \(type(of: myCube))")
print("cube: \(myCube(10))")



// (Int, Int) -> Void
func add(p1: Int, p2: Int) {
    print("addition: \(p1 + p2)")
}

// (Int, Int) -> Void
func subtract(p1: Int, p2: Int) {
    print("subtraction: \(p1 - p2)")
}


func executor2(function: (Int) -> Bool) {
    print("value for 10: \(function(10))")
}

executor2(function: isEven)
executor2(function: isOdd)

func executor(function: (Int, Int) -> Void) {
    function(10, 20)
}

//executor(func: 10)
//executor(func: "10")

executor(function: add)

let mySubtract: (Int, Int) -> Void = subtract
executor(function: mySubtract)


// closure
let multiply: (Int, Int) -> Void = { (p1: Int, p2: Int) -> Void  in
    print("multiplication: \(p1 * p2)")
}

//multiply(10, 20)
executor(function: multiply)

executor(function: { (p1: Int, p2: Int) -> Void in
    print("division: \(p1/p2)")
})




executor(function: { (p1, p2) in
    print("addition in clousure: \(p1 + p2)")
})


