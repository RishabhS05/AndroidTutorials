//
//  main.swift
//  Application10
//
//  Created by Amit Kulkarni on 12/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    let numbers = [100, 10, 40, 20, 50, 30, 90, 70, 80]
    
    let descendingNumbers = numbers.sorted(by: { (p1, p2) -> Bool in
        return p1 > p2
    });
    print("descendingNumbers: \(descendingNumbers)")
    
    let ascendingNumbers = numbers.sorted(by: { (p1, p2) in
        return p1 < p2
    })
    print("ascendingNumbers: \(ascendingNumbers)")
    
    let descendingNumbers2 = numbers.sorted(by: { return $0 > $1 });
    print("descendingNumbers: \(descendingNumbers2)")
    
    let ascendingNumbers2 = numbers.sorted(by: { $0 < $1 })
    print("ascendingNumbers: \(ascendingNumbers2)")
    
    let descendingNumbers3 = numbers.sorted(by: >);
    print("descendingNumbers: \(descendingNumbers3)")
    
    let ascendingNumbers3 = numbers.sorted(by: <)
    print("ascendingNumbers: \(ascendingNumbers3)")
}

//function1()


func function2() {
    let countries = ["Austrilia", "India", "USA", "UK", "Japan", "Sri Lanka", "Maldeev"]
    print("ascending: \(countries.sorted(by: <))")
    print("descending: \(countries.sorted(by: >))")
}

function2()


















