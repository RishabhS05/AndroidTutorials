//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 25/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

// NSObject: root class for Objective-C
class MyAnnotation: NSObject, MKAnnotation {
    
    var name: String!
    var information: String!
    var location: CLLocationCoordinate2D!
    var image: String!
    
    var coordinate: CLLocationCoordinate2D {
        get { return location }
    }
    
    var title: String? {
        get { return name }
    }
    
    var subtitle: String? {
        get { return information }
    }
    
    init(name: String, information: String, location: CLLocationCoordinate2D, image: String) {
        self.name = name
        self.information = information
        self.location = location
        self.image = image
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var segmentedControlMapType: UISegmentedControl!
    @IBOutlet weak var mapView: MKMapView!
    
    let locations = [
        MyAnnotation(name: "Swargate", information: "very noisy place", location: CLLocationCoordinate2D(latitude: 18.499440, longitude: 73.859164), image: "swargate.jpg"),
        MyAnnotation(name: "PVG College", information: "a college", location: CLLocationCoordinate2D(latitude: 18.490263, longitude: 73.853338), image: "pvg.jpg"),
        MyAnnotation(name: "Pune Station", information: "Pune Station place", location: CLLocationCoordinate2D(latitude: 18.528862, longitude: 73.873862), image: "pune_station.jpg"),
        MyAnnotation(name: "Shivaji Nagar", information: "very very noisy place", location: CLLocationCoordinate2D(latitude: 18.532107, longitude: 73.851578), image: "shivaji_nagar.jpg")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        addLocations()
    }
    
    func addLocations() {
        for location in locations {
            mapView.addAnnotation(location)
        }
        
        // set the region (used to zoom on an area)
        let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 18.5204, longitude: 73.8567), latitudinalMeters: 7000, longitudinalMeters: 7000)
        mapView.setRegion(region, animated: true)
    }

    @IBAction func onMapTypeChange() {
        if segmentedControlMapType.selectedSegmentIndex == 0 {
            mapView.mapType = .standard
        } else if segmentedControlMapType.selectedSegmentIndex == 1 {
            mapView.mapType = .hybrid
        } else if segmentedControlMapType.selectedSegmentIndex == 2 {
            mapView.mapType = .satellite
        }
    }
    
}

extension ViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        vc.selectedAnnotation = view.annotation as? MyAnnotation
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let myAnnotation = annotation as! MyAnnotation
        let annotationView =  MKPinAnnotationView(annotation: annotation, reuseIdentifier: nil)
        annotationView.canShowCallout = true
        annotationView.rightCalloutAccessoryView = UIButton(type: .infoLight)
        let imageView = UIImageView(image: UIImage(named: myAnnotation.image))
        imageView.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        annotationView.leftCalloutAccessoryView = imageView
        return annotationView
    }
}

