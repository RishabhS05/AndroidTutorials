//
//  DetailsViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 25/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import MessageUI

class DetailsViewController: UIViewController {

    var selectedAnnotation: MyAnnotation!
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var labelInformation: UILabel!
    @IBOutlet weak var labelTitle: UILabel!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Details"
        
        labelTitle.text = selectedAnnotation.title
        labelInformation.text = selectedAnnotation.information
        imageView.image = UIImage(named: selectedAnnotation.image)
    }
    
    
    @IBAction func sendSMS() {
        let vc = MFMessageComposeViewController()
        vc.subject = "subject"
        vc.body = "this is SMS"
        vc.messageComposeDelegate = self
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func sendEmail() {
        let vc = MFMailComposeViewController()
        vc.setSubject("this is the subject")
        vc.setToRecipients(["amit.kulkarni@sunbeaminfo.com"])
        vc.setMessageBody("this is the body", isHTML: false)
        vc.mailComposeDelegate = self
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func openWebsite() {
        // will use safari app
        let url = URL(string: "https://apple.com")
        UIApplication.shared.open(url!, options: [:], completionHandler: nil)
    }
    
    @IBAction func makePhoneCall() {
        // will use the phone app
        let url = URL(string: "tel://+9123432423424")
        UIApplication.shared.open(url!, options: [:], completionHandler: nil)
    }
}

extension DetailsViewController: MFMessageComposeViewControllerDelegate {
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        dismiss(animated: true, completion: nil)
    }
}

extension DetailsViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        dismiss(animated: true, completion: nil)
    }
}
