//
//  MovieCollectionViewCell.swift
//  Application3
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewMovie: UIImageView!
    
    @IBOutlet weak var labelTitle: UILabel!
}
