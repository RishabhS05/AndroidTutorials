//
//  ViewController.swift
//  Application3
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher

class ViewController: UIViewController {
    var movies: [Movie] = []
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    let url = "http://localhost:3000"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadAllMovies()
    }

    func loadAllMovies() {
        Alamofire
            .request(url + "/movie")
            .responseJSON(completionHandler: {response in
                let result = response.result.value as! [String: Any]
                self.movies.removeAll()
              
                let array = result["data"] as! [[String: Any]]
                for item in array {
                    let movie = Movie()
                    movie.title = item["title"] as? String
                    movie.year = item["year"] as? Int
                    movie.length = item["length"] as? String
                    movie.thumbnail = item["thumbnail"] as? String
                    self.movies.append(movie)
                }
                
                self.collectionView.reloadData()
//                self.searchBar.resignFirstResponder()
            })
    }

    func searchMovies() {
        if searchBar.text!.count == 0 {
            loadAllMovies()
        } else {
            Alamofire
                .request(url + "/movie/search/" + searchBar.text!)
                .responseJSON(completionHandler: {response in
                    let result = response.result.value as! [String: Any]
                    self.movies.removeAll()
                    
                    let array = result["data"] as! [[String: Any]]
                    for item in array {
                        let movie = Movie()
                        movie.title = item["title"] as? String
                        movie.year = item["year"] as? Int
                        movie.length = item["length"] as? String
                        movie.thumbnail = item["thumbnail"] as? String
                        self.movies.append(movie)
                    }
                    
                    self.collectionView.reloadData()
//                    self.searchBar.resignFirstResponder()
                })
        }
    }
    
}

extension ViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
         searchMovies()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchBar.resignFirstResponder()
        loadAllMovies()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchMovies()
    }
}


extension ViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        let movie = movies[indexPath.row]
        cell.labelTitle.text = movie.title
        
        let imageUrl = URL(string: url + "/\(movie.thumbnail!)")
        cell.imageViewMovie.kf.setImage(with: imageUrl)
        cell.imageViewMovie.layer.cornerRadius = 10
        
        return cell
    }
    
    
}

extension ViewController: UICollectionViewDelegate {
    
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (view.frame.width / 3) - 10
        return CGSize(width: width, height: 200)
    }
}
