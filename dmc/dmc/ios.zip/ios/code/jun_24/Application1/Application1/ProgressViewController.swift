//
//  ProgressViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ProgressViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.alpha = 0
        // Do any additional setup after loading the view.
    }

}
