//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var viewProgress: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }


    @IBAction func showProgress() {
        viewProgress.isHidden = false
        Alamofire
            .request("http://dummy.restapiexample.com/api/v1/employees")
            .responseJSON(completionHandler: {response in
                let employees = response.result.value as! [[String:String]]
                for employee in employees {
                    print(employee)
                }
                
                self.viewProgress.isHidden = true
            })
    }
}

