//
//  ViewController2.swift
//  Application1
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Alamofire

class ViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func loadAllTodos() {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProgressViewController")
        vc.modalTransitionStyle = .crossDissolve
        present(vc, animated: true, completion: nil)
        
        Alamofire
            .request("https://jsonplaceholder.typicode.com/todos")
            .responseJSON(completionHandler: { response in
                let result = response.result.value as! [[String:Any]]
                for todo in result {
                    print(todo)
                }
                
                self.dismiss(animated: true, completion: nil)
            })
    }
}
