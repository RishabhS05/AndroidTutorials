//
//  ViewController3.swift
//  Application1
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {

    @IBOutlet weak var progressView: UIProgressView!
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func changeProgress(_ sender: UIButton) {
        print("inside change progress: \(sender.tag)")
        let progress =  Float(sender.tag) / 100.0
        print(progress)
        // 0 - 1
        progressView.progress = progress
    }
}
