//
//  ViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelResult: UILabel!
    
    var currentNumber = ""
    var first: Float = 0
    var operation = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        labelResult.text = "0"
    }

    @IBAction func onClickDigit(_ sender: UIButton) {
        currentNumber += String(sender.tag)
        labelResult.text = currentNumber
    }
    
    @IBAction func onClickOperation(_ sender: UIButton) {
        first = Float(currentNumber)!
        operation = sender.tag
        labelResult.text = "0"
        currentNumber = ""
    }
    
    @IBAction func onClickDot() {
    }
    
    @IBAction func onClickEquals() {
        let second = Float(currentNumber)!
        var result: Float = 0.0
        if operation == 1 {
            result = first + second
        } else if operation == 2 {
            result = first - second
        } else if operation == 3 {
            result = first / second
        } else if operation == 4 {
            result = first * second
        }
        
        labelResult.text = String(result)
        currentNumber = ""
    }
}

