//
//  ViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var editUrl: UITextField!
    
    @IBOutlet weak var viewProgress: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.navigationDelegate = self
        loadUrl(strUrl: "https://apple.com")
    }
    
    @IBAction func onBrowse() {
        editUrl.resignFirstResponder()
        loadUrl(strUrl: editUrl.text!)
    }
    
    func loadUrl(strUrl: String) {
        
        viewProgress.isHidden = false
        
        // load the html
        // webView.loadHTMLString("<h1>welcome to iOS web app </h1>", baseURL: nil)
        
        // load external websites
        let url = URL(string: strUrl)
        let request = URLRequest(url: url!)
        webView.load(request)
    }


}

extension  ViewController: WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        viewProgress.isHidden = true
    }
}

