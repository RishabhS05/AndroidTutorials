//
//  ViewController.swift
//  Application4
//
//  Created by Amit Kulkarni on 24/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scrollview: UIScrollView!
    @IBOutlet weak var pageControl: UIPageControl!
    let images = ["angry_birds.jpg", "arise.jpg", "batman.jpg", "blowout.jpg", "boss_baby.jpg", "cars.jpg", "cars_2.jpg", "finding_dory.jpg", "frozen.jpg", "ice_age_4.jpg", "kung_fu_panda3.jpg", "leap.jpg", "moana.jpg", "resident_evil_2017.jpg", "resident_evit.jpg", "robin_hood.jpg", "shrek.jpg", "shrek_2.jpg", "shrek_3.jpg", "smurfs.jpg", "stoks.jpg"]
    
    var timer: Timer!
    var imageIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var index = 0
        for image in images {
            let imageView = UIImageView(frame: CGRect(x: 260 * index, y: 0, width: 260, height: 380))
            imageView.image = UIImage(named: image)
            scrollview.addSubview(imageView)
            index += 1
        }
        
        scrollview.contentSize = CGSize(width: 260 * images.count, height: 380)
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(changePage), userInfo: nil, repeats: true)
        
        pageControl.numberOfPages = images.count
    }
    
    @objc func changePage() {
        print("changePage")
        imageIndex += 1
        if imageIndex >= images.count {
            imageIndex = 0
        }
        
        pageControl.currentPage = imageIndex
        scrollview.contentOffset = CGPoint(x: imageIndex * 260, y: 0)
    }


}

