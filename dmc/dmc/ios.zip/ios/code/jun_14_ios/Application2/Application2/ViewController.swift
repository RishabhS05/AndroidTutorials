//
//  ViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func onLaunchSecondViewController() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let secondViewController =  storyboard.instantiateViewController(withIdentifier: "SecondViewController")
        secondViewController.modalTransitionStyle = .partialCurl
        present(secondViewController, animated: true, completion: nil)
    }
    
}

