//
//  SecondViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onBack() {
        dismiss(animated: true, completion: nil)
    }
    
}
