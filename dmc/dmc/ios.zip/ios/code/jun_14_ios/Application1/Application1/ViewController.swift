//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var editFirstName: UITextField!
    @IBOutlet weak var editLastName: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editAge: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func onSave() {
        print("onSave called")
        
        if editFirstName.text!.count == 0 {
            print("enter first name")
        } else if editLastName.text!.count == 0 {
            print("enter last name")
        } else if editAddress.text!.count == 0 {
            print("enter address")
        } else {
            print("First Name: \(editFirstName.text!)")
            print("Last Name: \(editLastName.text!)")
            print("Address: \(editAddress.text!)")
            print("Phone: \(editPhone.text!)")
            print("Email: \(editEmail.text!)")
            print("Age: \(editAge.text!)")
            
            editFirstName.text = ""
            editLastName.text = ""
            editAddress.text = ""
            editPhone.text = ""
            editEmail.text = ""
            editAge.text = ""
        }
    }
    
    @IBAction func onCancel() {
        print("onCancel called")
        print("You can NOT exit the first screen programmatically")
    }
    
}

