//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // recyclerView.setAdapter(adapter);
        tableView.dataSource = self
        tableView.delegate = self
    }

}

extension ViewController: UITableViewDataSource  {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    // getCount() ->
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("number of rows in section: \(section)")
        return section == 0 ? 3 : 6
    }
    
    // onCreateViewHolder() and onBindViewHolder(,, int index)
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = "cell at [\(indexPath.section), \(indexPath.row)]"
        return cell
    }
    
    
}

extension ViewController: UITableViewDelegate {
    
}
