//
//  ViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    let countries = ["India", "USA", "UK", "China", "Japan"]
    let cars = ["i20", "Nano", "Innova", "XUV", "X5", "Swift", "Accent"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
    }

}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var rows = 0
        if section == 0 {
            rows = countries.count
        } else if section == 1 {
            rows = cars.count
        }
        
        return rows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        
        var value = ""
        if indexPath.section == 0 {
            value = countries[indexPath.row]
        } else if indexPath.section == 1 {
            value = cars[indexPath.row]
        }
        
        cell.textLabel?.text = value
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        var title: String? = nil
        if section == 0 {
            title = "list of countries"
        } else if section == 1 {
            title = "list of cars"
        }
        return title
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        var title: String? = nil
        if section == 0 {
            title = "end of list of countries"
        } else if section == 1 {
            title = "end of list of cars"
        }
        return title
    }
}

extension ViewController: UITableViewDelegate {
    
}

