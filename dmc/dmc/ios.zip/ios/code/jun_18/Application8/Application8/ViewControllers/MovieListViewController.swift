//
//  MovieListViewController.swift
//  Application8
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class MovieListViewController: UIViewController {
    
    @IBOutlet weak var tabelView: UITableView!
    
    let movies = [
        Movie(title: "The Boss Baby", directors: " Tom McGrath", writers: " Michael McCullers", stars: "Alec Baldwin", ratings: 6.3, year: 2017, shortDescription: "A suit-wearing, briefcase-carrying baby pairs up with his 7-year old brother to stop the dastardly plot of the CEO of Puppy Co.", storyline: "Seven-year-old Tim Templeton has always had an overactive imagination--and for the past seven years--life has been all peaches for him, getting all the love and affection from his caring parents. However, after the arrival of Boss Baby, an unexpected new brother dressed in a black suit complete with a tie and a briefcase, Tim won't be the centre of attention anymore, as the powerful sibling takes over the whole house, robbing him of all care, little by little. But, soon, Tim and the new Boss in a diaper will need to put differences aside and join forces, as a sneaky scheme involving the head of Puppy Co. threatens to tilt the balance of power towards their insidiously adorable furry antagonists, not to mention that the next Pet Convention is only in two days.", length: " 1h 37min", thumbnail: "boss_baby.jpg"),
        
        Movie(title: "Smurfs: The Lost Village", directors: "Kelly Asbury", writers: "Stacey Harman, Pamela Ribon", stars: "Demi Lovato, Rainn Wilson, Joe Manganiello |", ratings: 6.0, year: 2017, shortDescription: "In this fully animated, all-new take on the Smurfs, a mysterious map sets Smurfette and her friends Brainy, Clumsy, and Hefty on an exciting race through the Forbidden Forest, leading to the discovery of the biggest secret in Smurf history.", storyline: "In this fully animated, all-new take on the Smurfs, a mysterious map sets Smurfette and her best friends Brainy, Clumsy, and Hefty on an exciting and thrilling race, through the Forbidden Forest, filled with magical creatures to find a mysterious lost village before the evil wizard Gargamel does. Embarking on a roller-coaster journey full of action and danger, the Smurfs are on a course that leads to the discovery of the biggest secret in Smurf history!", length: "1h 30min", thumbnail: "smurfs.jpg"),
        
        Movie(title: "Frozen", directors: "Chris Buck, Jennifer Lee", writers: " Jennifer Lee", stars: " Kristen Bell", ratings: 7.5, year: 2013, shortDescription: "When the newly-crowned Queen Elsa accidentally uses her power to turn things into ice to curse her home in infinite winter, her sister Anna teams up with a mountain man, his playful reindeer, and a snowman to change the weather condition.", storyline: "Fearless optimist Anna teams up with rugged mountain man Kristoff and his loyal reindeer Sven and sets off on an epic journey to find her sister Elsa, whose icy powers have trapped the kingdom of Arendelle in eternal winter. Encountering Everest-like conditions, mystical trolls and a hilarious snowman named Olaf, Anna and Kristoff battle the elements in a race to save the kingdom. From the outside Elsa looks poised, regal and reserved, but in reality she lives in fear as she wrestles with a mighty secret: she was born with the power to create ice and snow. It's a beautiful ability, but also extremely dangerous. Haunted by the moment her magic nearly killed her younger sister Anna, Elsa has isolated herself, spending every waking minute trying to suppress her growing powers. Her mounting emotions trigger the magic, accidentally setting off an eternal winter that she can't stop. She fears she's becoming a monster and that no one, not even her sister, can help her", length: "1h 42min", thumbnail: "frozen.jpg"),
        
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        tabelView.dataSource = self
        tabelView.delegate = self
    }

}

extension MovieListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tabelView.dequeueReusableCell(withIdentifier: "movieCell") as! MovieTableViewCell
        let movie = movies[indexPath.row]
        cell.labelTitle.text = movie.title
        cell.labelYear.text = "(\(movie.year!)) | \(movie.length!)"
        cell.labelDirectors.text = movie.directors
        cell.labelWriters.text = movie.writers
        cell.labelStars.text = movie.stars
        cell.imageViewMovie.image = UIImage(named: movie.thumbnail)
        
        return cell
    }
    
}

extension MovieListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let movie = movies[indexPath.row]
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MovieDetailsViewController") as! MovieDetailsViewController
        vc.movie = movie
        present(vc, animated: true, completion: nil)
    }
}
