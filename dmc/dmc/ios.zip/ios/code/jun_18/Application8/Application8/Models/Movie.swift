//
//  Movie.swift
//  Application8
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Movie {
    var title: String!
    var directors: String!
    var writers: String!
    var stars: String!
    var ratings: Float!
    var year: Int!
    var shortDescription: String!
    var storyline: String!
    var length: String!
    var thumbnail: String!
    
    init(title: String, directors: String, writers: String, stars: String, ratings: Float, year: Int, shortDescription: String, storyline: String, length: String, thumbnail: String) {
        self.title = title
        self.directors = directors
        self.writers = writers
        self.stars = stars
        self.ratings = ratings
        self.year = year
        self.shortDescription = shortDescription
        self.storyline = storyline
        self.length = length
        self.thumbnail = thumbnail
    }
}
