//
//  MovieDetailsViewController.swift
//  Application8
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class MovieDetailsViewController: UIViewController {

    var movie: Movie!
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var labelTitle: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelTitle.text = movie.title
        imageView.image = UIImage(named: movie.thumbnail)
    }

    @IBAction func onBack() {
        dismiss(animated: true, completion: nil)
    }
}
