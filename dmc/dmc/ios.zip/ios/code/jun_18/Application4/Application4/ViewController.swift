//
//  ViewController.swift
//  Application4
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    let persons: [Person] = [
        Person(name: "person1", address: "Pune"),
        Person(name: "person2", address: "Mumbai"),
        Person(name: "person3", address: "Satara"),
        Person(name: "person4", address: "Karad"),
        Person(name: "person5", address: "Kolhapur"),
        Person(name: "person6", address: "Sangli"),
        Person(name: "person7", address: "Nashik"),
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
    }

}

extension ViewController : UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return persons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        
        let person = persons[indexPath.row]
        cell.textLabel?.text = person.name
        cell.detailTextLabel?.text = person.address
        cell.imageView?.image = UIImage(named: "person")
        
        return cell
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        print("selected row \(indexPath.section):\(indexPath.row)")
        let person = persons[indexPath.row]
        print("selected person: \(person.name!)")
        
        let alert = UIAlertController(title: "selection", message: "selected person name: \(person.name!), address: \(person.address!)", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

