//
//  Person.swift
//  Application4
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Person {
    var name: String!
    var address: String!
    
    init(name: String, address: String) {
        self.name = name
        self.address = address
    }
}
