//
//  MovieTableViewCell.swift
//  Application7
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class MovieTableViewCell: UITableViewCell {

    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var labelYear: UILabel!
    @IBOutlet weak var labelDirectors: UILabel!
    @IBOutlet weak var labelStars: UILabel!
    @IBOutlet weak var labelWriters: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
