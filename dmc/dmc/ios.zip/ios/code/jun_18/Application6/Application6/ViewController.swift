//
//  ViewController.swift
//  Application6
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let movies = [
        Movie(title: "Movie 1", year: 1998, directors: "director 1", writers: "writer 1", stars: "Star 1"),
        Movie(title: "Movie 2", year: 2001, directors: "director 2", writers: "writer 2", stars: "Star 2"),
        Movie(title: "Movie 3", year: 2003, directors: "director 3", writers: "writer 3", stars: "Star 3"),
        Movie(title: "Movie 4", year: 2005, directors: "director 4", writers: "writer 4", stars: "Star 4"),
        Movie(title: "Movie 5", year: 2010, directors: "director 5", writers: "writer 5", stars: "Star 5")
    ]
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
    }

}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell")!
        let movie = movies[indexPath.row]
        
        let labelTitle = cell.viewWithTag(1) as! UILabel
        labelTitle.text = movie.title
        
        let labelDirectors = cell.viewWithTag(2) as! UILabel
        labelDirectors.text = movie.directors
        
        let labelWriters = cell.viewWithTag(3) as! UILabel
        labelWriters.text = movie.writers
        
        let labelStars = cell.viewWithTag(4) as! UILabel
        labelStars.text = movie.stars
        
        let labelYear = cell.viewWithTag(5) as! UILabel
        labelYear.text = "Year: \(movie.year!)"
        
        return cell
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

