//
//  Model.swift
//  Application6
//
//  Created by Amit Kulkarni on 18/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Movie {
    var title: String!
    var year: Int!
    var directors: String!
    var writers: String!
    var stars: String!
    
    init(title: String, year: Int, directors: String, writers: String, stars: String) {
        self.title = title
        self.year = year
        self.directors = directors
        self.writers = writers
        self.stars = stars
    }
}
