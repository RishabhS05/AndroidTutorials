//
//  ContactListViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import CoreData

class ContactListViewController: BaseViewController {
    
    var contacts: [Contact] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(logout))
    }
    
    @objc func logout() {
        let alert = UIAlertController(title: "confirmation", message: "Are you sure you want to logout?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { alert in
            
            // similar to SharedPreferences
            let userDefaults = UserDefaults.standard
            userDefaults.setValue(false, forKey: "login_status")
            userDefaults.synchronize()
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.showLogin()
            
        }))
        present(alert, animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        reloadContacts()
    }
    
    func reloadContacts() {
        contacts.removeAll()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Contacts")
        let result = try! context.fetch(request) as! [NSManagedObject]
        
        for obj in result {
            let contact = Contact()
            contact.name = obj.value(forKey: "name") as? String
            contact.address = obj.value(forKey: "address") as? String
            contact.email = obj.value(forKey: "email") as? String
            contact.phone = obj.value(forKey: "phone") as? String
            contact.city = obj.value(forKey: "city") as? String
            
            contacts.append(contact)
        }
        
        try! context.save()
        
        tableView.reloadData()
    }

}

extension ContactListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        
        let contact = contacts[indexPath.row]
        cell.textLabel?.text = contact.name
        cell.detailTextLabel?.text = contact.address
        cell.accessoryType = .disclosureIndicator
        
        return cell
    }
    
}

extension ContactListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let vc = launchVC(withIndentifier: "ContactDetailsViewController") as! ContactDetailsViewController
        vc.contact = contacts[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
    
    // TODO: please add the "swipe to delete" functionality
}
