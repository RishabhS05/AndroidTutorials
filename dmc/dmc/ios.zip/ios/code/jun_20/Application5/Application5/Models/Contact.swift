//
//  Contact.swift
//  Application5
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Contact {
    var name: String!
    var address: String!
    var city: String!
    var email: String!
    var phone: String!
    
}
