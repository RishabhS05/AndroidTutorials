//
//  AddContactViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import CoreData

class AddContactViewController: BaseViewController {

    @IBOutlet weak var editCity: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Add Contact"
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(insertContact))
    }

    @objc func insertContact() {
        if editName.text!.count == 0 {
            showWarning(message: "please enter name")
        } else if editAddress.text!.count == 0 {
            showWarning(message: "please enter address")
        } else if editEmail.text!.count == 0 {
            showWarning(message: "please enter email")
        } else if editPhone.text!.count == 0 {
            showWarning(message: "please enter phone")
        } else if editCity.text!.count == 0 {
            showWarning(message: "please enter city")
        } else {
            
            // insert the contact
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let contact = NSEntityDescription.insertNewObject(forEntityName: "Contacts", into: context)
            contact.setValue(editName.text!, forKey: "name")
            contact.setValue(editAddress.text!, forKey: "address")
            contact.setValue(editEmail.text!, forKey: "email")
            contact.setValue(editPhone.text!, forKey: "phone")
            contact.setValue(editCity.text!, forKey: "city")

            try! context.save()
            
            navigationController?.popViewController(animated: true)
        }
    }
}
