//
//  RegisterViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import CoreData

class RegisterViewController: BaseViewController {

    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editPassword: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Register"
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Register", style: .done, target: self, action: #selector(registerUser))
    }
    
    @objc func registerUser() {
        if editName.text!.count == 0 {
            showWarning(message: "please enter name")
        } else if editPassword.text!.count == 0 {
            showWarning(message: "please enter password")
        } else if editEmail.text!.count == 0 {
            showWarning(message: "please enter email")
        } else {
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let user = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
            user.setValue(editName.text!, forKey: "name")
            user.setValue(editPassword.text!, forKey: "password")
            user.setValue(editEmail.text!, forKey: "email")

            try! context.save()
            
            navigationController?.popViewController(animated: true)
        }
    }

}
