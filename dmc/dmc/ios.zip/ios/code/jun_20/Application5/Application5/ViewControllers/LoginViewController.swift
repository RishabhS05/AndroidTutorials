//
//  LoginViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import CoreData

class LoginViewController: BaseViewController {

    @IBOutlet weak var editPassword: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func login() {
        if editEmail.text!.count == 0 {
            showWarning(message: "please enter email")
        } else if editPassword.text!.count == 0 {
            showWarning(message: "please enter password")
        } else {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            request.predicate = NSPredicate(format: "email = %@ && password = %@", editEmail.text!, editPassword.text!)
            
            let users = try! context.fetch(request) as! [NSManagedObject]
            if users.count == 0 {
                // user not found
                showWarning(message: "Invalid email or password")
            } else {
                // user found
                
                // similar to SharedPreferences
                let userDefaults = UserDefaults.standard
                userDefaults.setValue(true, forKey: "login_status")
                userDefaults.synchronize()
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.showContactListVC()
            }
            
        }
    }
}
