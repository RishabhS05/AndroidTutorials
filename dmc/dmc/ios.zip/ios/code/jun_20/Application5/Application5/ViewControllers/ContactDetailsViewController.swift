//
//  ContactDetailsViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ContactDetailsViewController: BaseViewController {

    @IBOutlet weak var labelCity: UILabel!
    @IBOutlet weak var labelPhone: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var labelName: UILabel!
    
    var contact: Contact!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Details"
        
        labelName.text = "Name: \(contact.name!)"
        labelCity.text = "City: \(contact.city!)"
        labelPhone.text = "Phone: \(contact.phone!)"
        labelEmail.text = "Email: \(contact.email!)"
        labelAddress.text = "Address: \(contact.address!)"
    }

}
