//
//  PersonDetailsViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class PersonDetailsViewController: UIViewController {
    
    @IBOutlet weak var labelName: UILabel!
    var personName: String!

    override func viewDidLoad() {
        super.viewDidLoad()
        labelName.text = personName
    }
}
