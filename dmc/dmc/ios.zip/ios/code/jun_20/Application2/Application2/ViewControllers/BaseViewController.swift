//
//  BaseViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func launchVC(withIdentifider id: String) -> UIViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: id)
    }
}
