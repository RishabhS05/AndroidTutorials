//
//  MobileListViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class MobileListViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    
    let list = ["Mobile1", "Mobile2", "Mobile3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Mobiles"
    }
    
}

extension MobileListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
	//setting index of [list] index text to cells textlabel to view list
        cell.textLabel?.text = list[indexPath.row]
        return cell  //return this name of row
    }
    
}

extension MobileListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        //when row is selected launch vc
        let vc = launchVC(withIdentifider: "MobileDetailsViewController") as! MobileDetailsViewController
	//push-->to goto next page        pop-->to goto previous page
        navigationController?.pushViewController(vc, animated: true)
    }
}

