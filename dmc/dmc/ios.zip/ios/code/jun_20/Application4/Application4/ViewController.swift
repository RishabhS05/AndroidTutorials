//
//  ViewController.swift
//  Application4
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var persons: [PersonObj] = []

    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func insert() {
        // step1: get the app delegate object
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        // step2: get the context
        let context = appDelegate.persistentContainer.viewContext
        
        // step3: perform the operation
        
        // insert an empty row
	//NSEntityDescription==>description of database(entity)
        let object = NSEntityDescription.insertNewObject(forEntityName: "Person", into: context)
        object.setValue(editName.text!, forKey: "name")
        object.setValue(editAddress.text!, forKey: "address")
        object.setValue(editEmail.text!, forKey: "email")
        object.setValue(editPhone.text!, forKey: "phone")

        // step4: save the context if required
        try! context.save()
        
        print("inserted a new person record")
    }
    
    @IBAction func query() {
        persons.removeAll()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        let result = try! context.fetch(fetchRequest) as! [NSManagedObject]
        
        for person in result {
            let obj = PersonObj()
            obj.name = person.value(forKey: "name") as? String
            obj.address = person.value(forKey: "address") as? String
            obj.email = person.value(forKey: "email") as? String
            obj.phone = person.value(forKey: "phone") as? String
            
            persons.append(obj)
        }
        
        tableView.reloadData()
        try! context.save()
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return persons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        let person = persons[indexPath.row]
        
        cell.textLabel?.text = person.name
        cell.detailTextLabel?.text = person.address
        return cell
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let action =  UITableViewRowAction(style: .destructive, title: "delete", handler: {(action, indexPath) in
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            //get data 
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
            let result = try! context.fetch(fetchRequest) as! [NSManagedObject]
            let person = result[indexPath.row]
            
            context.delete(person)
            //save data
            try! context.save()
            
            // refresh the tableView
            self.query()
        })
        
        return [action]
    }
}
