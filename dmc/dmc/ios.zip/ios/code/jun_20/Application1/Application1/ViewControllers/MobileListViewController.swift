//
//  MobileListViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 20/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class MobileListViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
