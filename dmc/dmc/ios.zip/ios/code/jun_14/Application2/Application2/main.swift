//
//  main.swift
//  Application2
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

enum MyError : Error  {
    case AgeError
}

func function1(age: Int) throws {
    // age > 15 and age < 60
    if (age > 15) && (age < 60) {
        print("age is valid")
    } else {
        throw MyError.AgeError
    }
}

enum MyError2: Error {
    case InvalidParameter
}

func divide(p1: Int, p2: Int) throws -> Int {
    if p2 == 0 {
        throw MyError2.InvalidParameter
    }
    return p1 / p2
}


enum MyError3 : Error  {
    case TestError
}

func function3() throws {
    throw MyError3.TestError
}


//try! function1(age: 20)
//let division = try! divide(p1: 30, p2: 5)

func function4(age: Int) throws {
    if (age > 15) && (age < 60) {
        print("age is valid")
    } else {
        throw MyError.AgeError
    }
    
    let p2 = 10
    if p2 == 0 {
        throw MyError2.InvalidParameter
    }
    
    throw MyError3.TestError
}

do {
    try function4(age: 10)
} catch MyError.AgeError {
    print("age error")
} catch MyError2.InvalidParameter {
    print("invalid parameter")
} catch MyError3.TestError {
    print("Test Error")
} catch {
    print("error occurred")
}

//do {
//
//    try function1(age: 20)
//
//    let result = try divide(p1: 10, p2: 2)
//    print("result: \(result)")
//
//    try function3()
//
//} catch MyError.AgeError {
//    print("error occurred for age")
//} catch MyError2.InvalidParameter {
//    print("error occurred for invalid parameter")
//} catch {
//    print("generic catch block")
//}
