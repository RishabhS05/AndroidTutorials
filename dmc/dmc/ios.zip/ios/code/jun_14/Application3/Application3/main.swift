//
//  main.swift
//  Application3
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

@objc protocol Shape {
    func area() // required
    func draw() // required
    @objc optional func erase()
}

class Rectangle : Shape {
    func area() {
        print("area of rectangle")
    }
    
    func draw() {
        print("Rectangle is getting drawn")
    }
    
    func erase() {
        print("Rectangle is erased")
    }
}

class Square: Shape {
    func area() {
        print("area of square")
    }
    
    func draw() {
        print("Square is getting drawn")
    }
    
}

let shape1: Shape = Rectangle()
let shape2: Shape = Square()

shape1.area()
shape1.draw()

shape2.area()
shape2.draw()

shape1.erase?()
shape2.erase?()

//if shape1.erase == nil {
//    print("method erase does not exist in rectangle")
//} else {
//    shape1.erase!()
//}
//
//if shape2.erase == nil {
//    print("method erase does not exist in square")
//} else {
//    shape2.erase!()
//}
