//
//  main.swift
//  Application4
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

protocol Shape1 {
    func area()
}

protocol Shape2 {
    func erase()
}

protocol Shape3 {
    func draw()
}

class Rectangle {
    var height: Int?
    var width: Int?
    
    init(height: Int, width: Int) {
        self.height = height
        self.width = width
    }
    
    //
    //
    //
    //
}

extension Rectangle {
    func myFunction() {
        print("inside myFunction")
    }
}

extension Rectangle: Shape1 {
    func area() {
        print("area of rectangle: \(height! * width!)")
    }
}

extension Rectangle: Shape2 {
    func erase() {
        print("Rectangle is erased")
    }
}

extension Rectangle: Shape3 {
    func draw() {
        print("drawing rectangle")
    }
}

let r = Rectangle(height: 10, width: 30)
r.draw()
r.area()
r.erase()
r.myFunction()
