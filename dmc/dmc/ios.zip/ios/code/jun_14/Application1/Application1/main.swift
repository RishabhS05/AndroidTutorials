//
//  main.swift
//  Application1
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Person {
    var firstName: String?
    var lastName: String?
    var address: String?
    
    var fullName: String? {
        willSet(newFullName) {
            print("inside willSet: \(newFullName!)")
        }
        
        didSet {
            print("inside didSet")
        }
    }
}

let p1 = Person()
p1.fullName = "bill gates"

