//
//  main.swift
//  Application5
//
//  Created by Amit Kulkarni on 14/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

let array: [Int] = [1, 2, 3, 4, 5]
print("0th: \(array[0])")

class Student {
    var name: String?
    var rollNo: Int?
    
    init(name: String, rollNo: Int) {
        self.name = name
        self.rollNo = rollNo
    }
    
    var details: String {
        get {
            return "Name: \(name!) Roll No: \(rollNo!)"
        }
    }
}

class Students {
    let array = [
        Student(name: "s1", rollNo: 1),
        Student(name: "s2", rollNo: 2),
        Student(name: "s3", rollNo: 3),
        Student(name: "s4", rollNo: 4)
    ]
    
    subscript(index: Int) -> Student {
        get {
            return array[index]
        }
    }
}

let students = Students()
print(students[0].details)
print(students[1].details)
print(students[2].details)
print(students[3].details)
