//
//  RegisterViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class RegisterViewController: BaseViewController {

    @IBOutlet weak var editPassword: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Register"
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(onRegister))
    }
    
    @objc func onRegister() {
        let body = [
            "email": editEmail.text!,
            "password": editPassword.text!,
            "name": editName.text!,
            "phone": editPhone.text!
        ]
        
        makeApiCall(
            api: "/user/signup",
            onSuccess: { result in
                self.view.makeToast("successfully registered your account")
                self.navigationController?.popViewController(animated: true)
            }, parameters: body)
    }
    
}
