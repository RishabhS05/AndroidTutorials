//
//  ItemTableViewCell.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ItemTableViewCell: UITableViewCell {

    @IBOutlet weak var labelCompany: UILabel!
    @IBOutlet weak var buttonAdd: UIButton!
    @IBOutlet weak var labelPrice: UILabel!
    @IBOutlet weak var labelUnit: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var imageViewItem: UIImageView!
    
    @IBOutlet weak var labelQty: UILabel!
    @IBOutlet weak var stepper: UIStepper!
    
    var onAddItem: (() -> Void)!
    var onQtyChange: ((Int) -> Void)!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    @IBAction func onStepperChange() {
        labelQty.text = "\(Int(stepper.value))"
        onQtyChange(Int(stepper.value))
    }
    
    @IBAction func onAdd() {
        onAddItem()
    }
}
