//
//  ProfileViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Kingfisher

class ProfileViewController: BaseViewController {
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var labelPhone: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var labelName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(logout))
    }
    
    @objc func logout() {
        AppPreferences.logout()
        
        let appDelegate = UIApplication.shared.delegate as!  AppDelegate
        appDelegate.showLogin()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadProfile()
    }
    
    func loadProfile() {
        makeApiCall(
            api: "/user/profile/\(AppPreferences.userId)",
            onSuccess: {result in
                let user = result as! [String: Any]
                
                self.labelName.text = user["name"] as? String
                self.labelEmail.text = user["email"] as? String
                self.labelPhone.text = user["phone"] as? String
                
                let imageUrl = URL(string: self.url + "/\(user["profileImage"] as! String)")
                self.imageView.kf.setImage(with: imageUrl)
        }, method: .get)
    }
}
