//
//  Movie.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Movie {
    var id: Int!
    var title: String!
    var year: Int!
    var rating: Float!
    var thumbnail: String!
    var directors: String!
    var writers: String!
    var genre: String!
    var length: String!
    var shortDescription: String!
    var storyline: String!
}
