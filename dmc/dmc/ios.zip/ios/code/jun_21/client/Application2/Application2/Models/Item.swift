//
//  Item.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Item {
    var id: Int!
    var name: String!
    var company: String!
    var thumbnail: String!
    var unit: String!
    var price: Float!
    var quantity: Int!
}
