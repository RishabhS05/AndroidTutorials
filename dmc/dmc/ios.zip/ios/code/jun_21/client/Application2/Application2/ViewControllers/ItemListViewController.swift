//
//  ItemListViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Kingfisher
import Toast_Swift

class ItemListViewController: BaseViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var items: [Item] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadItems()
    }
    
    func loadItems() {
        makeApiCall(
            api: "/item",
            onSuccess: { response in
                self.items.removeAll()
                let array = response as! [[String: Any]]
                for obj in array {
                    let item = Item()
                    item.id = obj["id"] as? Int
                    item.name = obj["title"] as? String
                    item.price = obj["price"] as? Float
                    item.company = obj["company"] as? String
                    item.unit = obj["unit"] as? String
                    item.thumbnail = obj["thumbnail"] as? String
                    self.items.append(item)
                }
                self.tableView.reloadData()
        }, method: .get)
    }
    
}

extension ItemListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell") as! ItemTableViewCell
        let item = items[indexPath.row]
        
        cell.labelName.text = item.name
        cell.labelCompany.text = item.company
        cell.labelUnit.text = item.unit
        cell.labelPrice.text = "\(item.price!)"
        
        let imageUrl = URL(string: url + "/\(item.thumbnail!)")
        cell.imageViewItem.kf.setImage(with: imageUrl)
        cell.imageViewItem.layer.cornerRadius = 10
        
        cell.buttonAdd.layer.shadowColor = Color.lightGray.cgColor
        cell.buttonAdd.layer.shadowRadius = 5
        cell.buttonAdd.layer.shadowOffset = CGSize(width: 5, height: 5)
        cell.buttonAdd.layer.shadowOpacity = 1
        
        cell.onAddItem = { () in
            let body: [String : Any] = [
                "userId": AppPreferences.userId,
                "itemId": item.id!,
                "price": item.price!
            ]
            
            self.makeApiCall(
                api: "/cart",
                onSuccess: { response in
                self.view.makeToast("Added item to Cart")
            }, parameters: body)
        }
        
        return cell
    }
    
}

extension ItemListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
