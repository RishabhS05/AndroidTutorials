//
//  MovieListViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Kingfisher

class MovieListViewController: BaseViewController {
    
    var movies: [Movie] = []

    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadMovies()
    }

    func loadMovies() {
        makeApiCall(api: "/movie", onSuccess: { result in
            self.movies.removeAll()
            
            let array = result as! [[String: Any]]
            for item in array {
                let movie = Movie()
                movie.title = item["title"] as? String
                movie.year = item["year"] as? Int
                movie.length = item["length"] as? String
                movie.thumbnail = item["thumbnail"] as? String
                self.movies.append(movie)
            }
            
            self.collectionView.reloadData()
        }, method: .get)
    }
    
}

extension MovieListViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        let movie = movies[indexPath.row]
        cell.labelTitle.text = movie.title
        cell.labelInfo.text = "\(movie.year!) | \(movie.length!)"
        
        let imageUrl = URL(string: url + "/\(movie.thumbnail!)")
        cell.imageViewMovie.kf.setImage(with: imageUrl)
        cell.imageViewMovie.layer.cornerRadius = 10
        
        return cell
    }
    
    
}

extension MovieListViewController: UICollectionViewDelegate {
    
}

extension MovieListViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (view.frame.width / 3) - 10
        return CGSize(width: width, height: 200)
    }
}
