//
//  LoginViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Toast_Swift

class LoginViewController: BaseViewController {
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onLogin() {
        if editEmail.text!.count == 0 {
            showWarning(message: "Please enter email")
        } else if editPassword.text!.count == 0 {
            showWarning(message: "Please enter password")
        } else {
            
            let body = [
                "email": editEmail.text!,
                "password": editPassword.text!
            ]
            
            makeApiCall(api: "/user/signin",
                onSuccess: { result in
                    let user = result as! [String: Any]
                    let name = user["name"] as! String
                    let userId = user["id"] as! Int
                    let email = user["email"] as! String
                    
                    AppPreferences.loginUser(name: name, email: email, userId: userId)
                    
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.showHome()
                    
                }, onError: { error in
                    self.view.makeToast("Invalid email or password")
            }, parameters: body)
        }
    }
}
