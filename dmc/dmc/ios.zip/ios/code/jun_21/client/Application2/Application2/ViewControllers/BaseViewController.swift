//
//  BaseViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Alamofire

class BaseViewController: UIViewController {

    let url = "http://localhost:3000"
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func showWarning(message: String) {
        view.makeToast(message)
    }
    
    func makeApiCall(api: String, onSuccess:@escaping ((_ data: Any?) -> Void), onError:((_ data: Any?) -> Void)? = nil, method: HTTPMethod = .post, parameters: Parameters? = nil) {
        
        print("calling api: \(api)")
        Alamofire
            .request(url + "\(api)", method: method, parameters: parameters)
            .responseJSON(completionHandler: { response in
                let result = response.result.value as! [String: Any]
                if result["status"] as! String == "success" {
                    onSuccess(result["data"])
                } else {
                    if let onError = onError {
                        onError(result["data"])
                    } else {
                        self.showWarning(message: "api error")
                    }
                }
            })
    }

}
