//
//  AppPreferences.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class AppPreferences {
    
    static let key_login_status = "login_status"
    static let key_user_id = "user_id"
    static let key_user_email = "user_email"
    static let key_user_name = "user_name"
    
    class var isUserLoggedIn: Bool {
        if let status = UserDefaults.standard.value(forKey: key_login_status) as? Bool {
            return status
        } else {
            return false
        }
    }
    
    class var userId : Int {
        if let userId = UserDefaults.standard.value(forKey: key_user_id) as? Int {
            return userId
        } else {
            return -1
        }
    }

    class func loginUser(name: String, email: String, userId: Int) {
        let userDefaults = UserDefaults.standard
        userDefaults.setValue(name, forKey: key_user_name)
        userDefaults.setValue(email, forKey: key_user_email)
        userDefaults.setValue(userId, forKey: key_user_id)
        userDefaults.setValue(true, forKey: key_login_status)
        userDefaults.synchronize()
    }
    
    class func logout() {
        let userDefaults = UserDefaults.standard
        userDefaults.setValue("", forKey: key_user_name)
        userDefaults.setValue("", forKey: key_user_email)
        userDefaults.setValue(-1, forKey: key_user_id)
        userDefaults.setValue(false, forKey: key_login_status)
        userDefaults.synchronize()
    }
}
