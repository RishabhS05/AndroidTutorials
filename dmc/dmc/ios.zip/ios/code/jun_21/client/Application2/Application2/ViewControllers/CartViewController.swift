//
//  CartViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class CartViewController: BaseViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var items: [Item] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadItems()
    }
    
    func loadItems() {
        makeApiCall(
            api: "/cart/\(AppPreferences.userId)",
            onSuccess: { response in
                self.items.removeAll()
                let array = response as! [[String: Any]]
                for obj in array {
                    let item = Item()
                    item.id = obj["cartId"] as? Int
                    item.name = obj["title"] as? String
                    item.price = obj["price"] as? Float
                    item.company = obj["company"] as? String
                    item.unit = obj["unit"] as? String
                    item.thumbnail = obj["thumbnail"] as? String
                    item.quantity = obj["quantity"] as? Int
                    self.items.append(item)
                }
                self.tableView.reloadData()
        }, method: .get)
    }

}



extension CartViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell") as! ItemTableViewCell
        let item = items[indexPath.row]
        
        cell.labelName.text = item.name
        cell.labelCompany.text = item.company
        cell.labelUnit.text = item.unit
        cell.labelPrice.text = "\(item.price!)"
        
        let imageUrl = URL(string: url + "/\(item.thumbnail!)")
        cell.imageViewItem.kf.setImage(with: imageUrl)
        cell.imageViewItem.layer.cornerRadius = 10
        cell.labelQty.text = "\(item.quantity!)"
        cell.stepper.value = Double(item.quantity!)
        
        cell.onQtyChange = { qty in
            
            if qty == 0 {
                
                self.makeApiCall(
                    api: "/cart/\(item.id!)",
                    onSuccess: { response in
                        self.loadItems()
                }, method: .delete)
                
            } else {
                let body = [
                    "quantity": qty
                ]
                
                self.makeApiCall(
                    api: "/cart/\(item.id!)",
                    onSuccess: { response in
                }, method: .put, parameters: body)
            }
        }
        
        return cell
    }
    
}

extension CartViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}

