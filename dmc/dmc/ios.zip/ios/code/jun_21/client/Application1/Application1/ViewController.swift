//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var students: [Student] = []
    let url = "http://localhost:3000/student"
    
    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func onSave() {
        let body = [
            "name": editName.text!,
            "address": editAddress.text!,
            "email": editEmail.text!,
            "phone": editPhone.text!
        ]
        
        Alamofire
            .request(url, method: .post, parameters: body)
            .responseJSON(completionHandler: { response in
                let result = response.result.value as! [String: Any]
                if result["status"] as! String == "success" {
                    print("added new student")
                } else {
                    print("error while adding a student")
                }
            })
        
    }
    
    @IBAction func onGet() {
        Alamofire
            .request(url)
            .responseJSON(completionHandler: {response in
                self.students.removeAll()
                
                let result = response.result.value as! [String: Any]
                let status = result["status"] as! String
                if status == "success" {
                    let data = result["data"] as! [[String: Any]]
                    for obj in data {
                        let student = Student()
                        student.id = obj["id"] as? Int
                        student.name = obj["name"] as? String
                        student.address = obj["address"] as? String
                        student.email = obj["email"] as? String
                        student.phone = obj["phone"] as? String
                        self.students.append(student)
                    }
                } else {
                    print("error while loading students")
                }
                
                self.tableView.reloadData()
            })
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let student = students[indexPath.row]
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.textLabel?.text = student.name
        cell.detailTextLabel?.text = "\(student.address!), \(student.email!), \(student.phone!)"
        return cell
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let student = self.students[indexPath.row]
        
        let action = UITableViewRowAction(style: .destructive, title: "delete", handler: {(action, indexPath) in
            
            Alamofire
                .request(self.url + "/\(student.id!)", method: .delete)
                .responseJSON(completionHandler: { response in
                    let result = response.result.value as! [String: Any]
                    if result["status"] as! String == "success" {
                        print("deleted student")
                        
                        self.onGet()
                        
                    } else {
                        print("error while deleting a student")
                    }
                })
            
        })
        
        let updateAction = UITableViewRowAction(style: .normal, title: "update", handler: { (action, indexPath) in
            
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UpdateStudentViewController") as! UpdateStudentViewController
            vc.student = student
            self.navigationController?.pushViewController(vc, animated: true)
        })
        
        return [action, updateAction]
        
    }
}

