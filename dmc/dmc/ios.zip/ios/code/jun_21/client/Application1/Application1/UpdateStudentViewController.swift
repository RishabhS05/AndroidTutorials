//
//  UpdateStudentViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit
import Alamofire

class UpdateStudentViewController: UIViewController {
    let url = "http://localhost:3000/student"
    var student: Student!
    
    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editEmail: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Update Student"
        editName.text = student.name
        editAddress.text = student.address
        editPhone.text = student.phone
        editEmail.text = student.email
        
        navigationItem.rightBarButtonItem =  UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(onSave))
    }
    
    @objc func onSave() {
        let body = [
            "name": editName.text!,
            "address": editAddress.text!,
            "email": editEmail.text!,
            "phone": editPhone.text!
        ]
        
        Alamofire
            .request(url + "/\(student.id!)", method: .put, parameters: body)
            .responseJSON(completionHandler: { response in
                let result = response.result.value as! [String: Any]
                if result["status"] as! String == "success" {
                    print("updated student")
                } else {
                    print("error while updating a student")
                }
                
                self.navigationController?.popViewController(animated: true)
            })
    }

}
