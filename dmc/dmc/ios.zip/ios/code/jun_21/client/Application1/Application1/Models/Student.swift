//
//  Student.swift
//  Application1
//
//  Created by Amit Kulkarni on 21/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Student {
    var id: Int!
    var name: String!
    var address: String!
    var email: String!
    var phone: String!
}
