const express = require('express');
const db = require('./db');
const utils = require('./utils');
const router = express.Router();

router.post('/student', (request, response) => {
    const {name, address, email, phone} = request.body;

    const connection = db.connect();
    const statement = `insert into student (name, address, email, phone) values ('${name}', '${address}', '${email}', '${phone}')`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});

router.get('/student', (request, response) => {
    const connection = db.connect();
    const statement = `select id, name, address, email, phone from student`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});

router.put('/student/:id', (request, response) => { 
    const id = request.params.id;
    const {name, address, email, phone} = request.body;

    const connection = db.connect();
    const statement = `update student set 
        name = '${name}', address = '${address}', email = '${email}', phone = '${phone}'  
        where id = ${id}`;
        
    console.log(statement);
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});

router.delete('/student/:id', (request, response) => {
    const id = request.params.id;
    const connection = db.connect();
    const statement = `delete from student where id = ${id}`;
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    })
});


module.exports = router;