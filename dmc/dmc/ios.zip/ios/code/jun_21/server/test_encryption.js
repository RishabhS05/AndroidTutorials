const cryptoJs = require('crypto-js');

const password = 'test';
console.log('visible password: ' + password);

const encryptedPassword1 = cryptoJs.MD5(password);
console.log('encrypted: ' + encryptedPassword1);

const encryptedPassword2 = cryptoJs.SHA256(password);
console.log('encrypted: ' + encryptedPassword2);