const express = require('express');
const db = require('./db');
const utils = require('./utils');

const router = express.Router();

router.post('/item/rating', (request, response) => {
    const { userId, itemId, rating } = request.body;

    const connection = db.connect();
    const queryStement = `select * from Rating where userId = ${userId} and itemId = ${itemId}`;
    connection.query(queryStement, (error, result) => {
        let statement = '';
        if (result.length == 0 ) {
            // user has not given any rating for this item
            statement = `insert into Rating (userId, itemId, rating) values (${userId},  ${itemId}, ${rating})`;
        } else {
            // user is changing the rating for this item
            statement = `update Rating set rating = ${rating} where userId = ${userId} and itemId = ${itemId}`;
        }

        connection.query(statement, (error, result) => {
            connection.end();
            response.send(utils.createResponse(error, result));
        })

    });

    
})

router.get('/item', (request, response) => {
    const statement = `select *, (select AVG(rating) from Rating where itemId = Item.id) as rating  from Item`;
    const connection = db.connect();
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    });
})

module.exports = router;