const express = require('express');
const db = require('./db');
const utils = require('./utils');

const router = express.Router();

router.post('/cart', (request, response) => {
    const {userId, itemId, price } = request.body;
    const queryStatement = `select * from Cart where userId = ${userId} and itemId = ${itemId}`;
    const connection = db.connect();
    connection.query(queryStatement, (error, result) => {
        // check if record exists for user and item pair
        if (result.length == 0) {

            // user is adding the item into the cart for  the first time
            const statement = `insert into Cart (userId, itemId, rate) values (${userId}, ${itemId}, ${price})`;
            connection.query(statement, (error, result) => {
                connection.end();
                response.send(utils.createResponse(error, result));
            });
        } else {

            // user already has added the item to the cart earlier
            const quantity = result[0]['quantity'];
            const id = result[0]['id'];
            const statement = `update Cart set quantity = ${quantity + 1} where id = ${id}`;
            connection.query(statement, (error, result) => {
                connection.end();
                response.send(utils.createResponse(error, result));
            });
        }
    });    
})

router.delete('/cart/:id', (request, response) => {
    const id = request.params.id;
    const statement = `delete from Cart  where id = ${id}`;
    const connection = db.connect();
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    });
})

router.put('/cart/:id', (request, response) => {
    
    const id = request.params.id;
    const {quantity} = request.body;

    const statement = `update Cart set quantity = ${quantity} where id = ${id}`;
    const connection = db.connect();

    console.log(statement);
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    });
})

router.get('/cart/:userId', (request, response) => {
    const userId = request.params.userId;
    const statement = `select Cart.id as cartId, Item.id as itemId, Cart.*, Item.* from Item, Cart Where userId = ${userId} and Item.id = Cart.itemId`;
    const connection = db.connect();
    connection.query(statement, (error, result) => {
        connection.end();
        response.send(utils.createResponse(error, result));
    });
})

module.exports = router;