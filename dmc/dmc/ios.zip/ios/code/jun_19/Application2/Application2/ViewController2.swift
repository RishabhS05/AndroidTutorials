//
//  ViewController2.swift
//  Application2
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    @IBOutlet weak var labelSelection: UILabel!
    let states = ["Goa", "Karnataka", "Maharashtra", "Rajasthan"]
    
    let data: [String: [String]] = [
        "Goa": ["Ponda", "Panaji"],
        "Karnataka": ["Belgaum", "Bengalore", "Maisur"],
        "Maharashtra": ["Pune", "Nashik", "Karad", "Satara"],
        "Rajasthan": ["Jaipur", "Udaypur", "Jodhpur", "Kota", "Pushkar"]
    ]
    
    @IBOutlet weak var pickerView: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}

extension ViewController2: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return states.count
        } else {
            let state = states[pickerView.selectedRow(inComponent: 0)]
            let cities = data[state]
            return cities!.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0 {
            return states[row]
        } else {
            let state = states[pickerView.selectedRow(inComponent: 0)]
            let cities = data[state]
            return cities![row]
        }
    }
}

extension ViewController2: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            pickerView.reloadComponent(1)
            pickerView.selectRow(0, inComponent: 1, animated: true)
        }
        
        let state = states[pickerView.selectedRow(inComponent: 0)]
        let cities = data[state]
        let city = cities![pickerView.selectedRow(inComponent: 1)]
        labelSelection.text = "\(city), \(state)"
    }
}
