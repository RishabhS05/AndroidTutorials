//
//  ViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var picker: UIPickerView!
    
    let cities = ["Pune", "Mumbai", "Nashik", "Satara", "Karad"]
    @IBOutlet weak var labelCity: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.dataSource = self
        picker.delegate = self
    }

    @IBAction func displaySelectedCity() {
        let city1 = cities[picker.selectedRow(inComponent: 0)]
        let city2 = cities[picker.selectedRow(inComponent: 1)]
        let city3 = cities[picker.selectedRow(inComponent: 2)]
        labelCity.text = "selected: \(city1), \(city2), \(city3)"
    }
}

extension ViewController: UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return cities.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return cities[row]
    }
}

extension ViewController: UIPickerViewDelegate {
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        displaySelectedCity()
    }
}

