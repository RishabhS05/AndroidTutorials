//
//  ViewController3.swift
//  Application1
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController3: UIViewController {
    
    @IBOutlet weak var buttonReorder: UIButton!
    var contacts: [Contact] = []
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        contacts.append(Contact(name: "contact 1", address: "address 1"))
        contacts.append(Contact(name: "contact 2", address: "address 2"))
        contacts.append(Contact(name: "contact 3", address: "address 3"))
        contacts.append(Contact(name: "contact 4", address: "address 4"))
        contacts.append(Contact(name: "contact 5", address: "address 5"))
    }
    
    @IBAction func toggleReorder(_ sender: Any) {
        tableView.isEditing = !tableView.isEditing
        if tableView.isEditing {
            buttonReorder.setTitle("Done", for: .normal)
        } else {
            buttonReorder.setTitle("Reorder", for: .normal)
        }
    }
    
}

extension ViewController3: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        let contact = contacts[indexPath.row]
        cell.textLabel?.text = contact.name
        return cell
    }
    
}

extension ViewController3: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
    }
}
