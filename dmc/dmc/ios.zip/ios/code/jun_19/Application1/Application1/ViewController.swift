//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var editAddress: UITextField!
    var contacts: [Contact] = []
    
    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        contacts.append(Contact(name: "contact 1", address: "address 1"))
        contacts.append(Contact(name: "contact 2", address: "address 2"))
        contacts.append(Contact(name: "contact 3", address: "address 3"))
        contacts.append(Contact(name: "contact 4", address: "address 4"))
        contacts.append(Contact(name: "contact 5", address: "address 5"))
        
    }
    
    @IBAction func onAdd() {
        
        // create  contact
        let contact = Contact(name: editName.text!, address: editAddress.text!)
        
        // add to the list
        contacts.append(contact)
        
        // refresh the table view
        // adapter.notifyDataSetChanged()
        tableView.reloadData()

        onCancel()
    }
    
    
    @IBAction func onCancel() {
        editName.text = ""
        editAddress.text = ""
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        let contact = contacts[indexPath.row]
        cell.textLabel?.text = contact.name
        return cell
    }
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        print("about to delete row at: \(indexPath.row)")
        
        contacts.remove(at: indexPath.row)
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "Remove"
    }
    
}
