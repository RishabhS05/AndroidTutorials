//
//  ViewController2.swift
//  Application1
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    var contacts: [Contact] = []
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        contacts.append(Contact(name: "contact 1", address: "address 1"))
        contacts.append(Contact(name: "contact 2", address: "address 2"))
        contacts.append(Contact(name: "contact 3", address: "address 3"))
        contacts.append(Contact(name: "contact 4", address: "address 4"))
        contacts.append(Contact(name: "contact 5", address: "address 5"))
    }
    
}


extension ViewController2: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        let contact = contacts[indexPath.row]
        cell.textLabel?.text = contact.name
        return cell
    }
    
}

extension ViewController2: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let actionDelete = UITableViewRowAction(style: .destructive, title: "delete"
            , handler: { (action, indexPath) in
                print("delete action performed")
                self.contacts.remove(at: indexPath.row)
                self.tableView.reloadData()
        })
        
        let actionUpdate = UITableViewRowAction(style: .normal, title: "update", handler: { (action, indexPath) in
            print("update action performed")
        })
        
        return [actionUpdate, actionDelete]
    }

}
