//
//  Contact.swift
//  Application1
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Contact {
    var name: String!
    var address: String!
    
    init(name: String, address: String) {
        self.name = name
        self.address = address
    }
}
