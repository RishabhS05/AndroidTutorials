//
//  Contact.swift
//  Application5
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Contact {
    var name: String!
    var address: String!
    var city: String!
    var phone: String!
    
    init() {
    }
    
    init(name: String, address: String, city: String, phone: String) {
        self.name = name
        self.address = address
        self.city = city
        self.phone = phone
    }
}
