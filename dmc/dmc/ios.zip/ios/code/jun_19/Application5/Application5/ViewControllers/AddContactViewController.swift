//
//  AddContactViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class AddContactViewController: BaseViewController {

    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editAddress: UITextView!
    @IBOutlet weak var editCity: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    
    var onSave: ((Contact) -> Void)!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // property to be displayed on navigation bar
        title = "Add Contact"
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(save))
    }
    
    @objc func save() {
        if editName.text!.count == 0 {
            showWarning(message: "please enter name")
        } else if editAddress.text!.count == 0 {
            showWarning(message: "please enter address")
        } else if editCity.text!.count == 0 {
            showWarning(message: "please enter city")
        } else if editPhone.text!.count == 0 {
            showWarning(message: "please enter phone")
        } else {
            let contact = Contact()
            contact.name = editName.text!
            contact.address = editAddress.text!
            contact.city = editCity.text!
            contact.phone = editPhone.text!
            
            // send the contact to previous VC
            onSave(contact)
            
            navigationController?.popViewController(animated: true)
        }
    }

}
