//
//  ContactListViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ContactListViewController: BaseViewController {
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var labelMessage: UILabel!
    var contacts: [Contact] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // property to be displayed on navigation bar
        title = "Contacts"
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addContact))
        
        refreshUI()
    }
    
    func refreshUI() {
        if contacts.count == 0 {
            labelMessage.isHidden = false
            tableView.isHidden = true
        } else {
            labelMessage.isHidden = true
            tableView.isHidden = false
        }
    }
    
    @objc func addContact() {
        let vc = launchVC(id: "AddContactViewController") as! AddContactViewController
        vc.onSave = { contact in
            self.contacts.append(contact)
            self.tableView.reloadData()
            self.refreshUI()
        }
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension ContactListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        let contact = contacts[indexPath.row]
        cell.textLabel?.text = contact.name
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
}

extension ContactListViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let vc = launchVC(id: "ContactDetailsViewController") as! ContactDetailsViewController
        vc.contact = contacts[indexPath.row]
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let deleteAction = UITableViewRowAction(style: .destructive, title: "delete", handler: {(action, indexPath) in
            self.deleteContact(indexPath: indexPath)
        })
        
        return [deleteAction]
    }
    
    func deleteContact(indexPath: IndexPath) {
        let alert = UIAlertController(title: "confirmation", message: "Are you sure you want to delete  this contact?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "No", style: .default, handler: nil))
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { alert in
            self.contacts.remove(at: indexPath.row)
            self.tableView.reloadData()
            self.refreshUI()
        }))
        present(alert, animated: true, completion: nil)       
    }
}
