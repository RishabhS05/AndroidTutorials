//
//  ContactDetailsViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 19/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ContactDetailsViewController: UIViewController {
    
    @IBOutlet weak var labelPhone: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelCity: UILabel!
    
    var contact: Contact!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // property to be displayed on navigation bar
        title = "Details"
        
        labelName.text = "Name: \(contact.name!)"
        labelAddress.text = "Address: \(contact.address!)"
        labelCity.text = "City: \(contact.city!)"
        labelPhone.text = "Phone: \(contact.phone!)"

    }

}
