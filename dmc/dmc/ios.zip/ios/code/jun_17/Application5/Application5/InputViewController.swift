//
//  InputViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class InputViewController: BaseViewController {

    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    
    var onSaveInfo: ((Person) -> Void)!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func onSave() {
        let person = Person(
            name: editName.text!,
            address: editAddress.text!,
            email: editEmail.text!,
            phone: editPhone.text!)
        
        onSaveInfo(person)
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func onCancel() {
        dismiss(animated: true, completion: nil)
    }
}
