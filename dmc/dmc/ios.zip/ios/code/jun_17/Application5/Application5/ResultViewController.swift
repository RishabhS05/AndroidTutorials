//
//  ResultViewController.swift
//  Application5
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ResultViewController: BaseViewController {

    @IBOutlet weak var labelPhone: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // (Person) -> Void
    func saveInfo(person: Person) {
        labelName.text = "Name: \(person.name!)"
        labelAddress.text = "Address: \(person.address!)"
        labelEmail.text = "Email: \(person.email!)"
        labelPhone.text = "Phone: \(person.phone!)"
    }
    
    @IBAction func getInformation() {
        let vc = launchVC(withIdentifier: "InputViewController") as! InputViewController
        // vc.onSaveInfo = saveInfo
        vc.onSaveInfo = { person in
            self.labelName.text = "Name: \(person.name!)"
            self.labelAddress.text = "Address: \(person.address!)"
            self.labelEmail.text = "Email: \(person.email!)"
            self.labelPhone.text = "Phone: \(person.phone!)"
        }
        present(vc, animated: true, completion: nil)
    }
    
}
