//
//  ViewController.swift
//  Application6
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    @IBOutlet weak var labelPhone: UILabel!
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func getInformation() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "InputViewController") as! InputViewController
        vc.onSaveInfo = { person in
            self.labelName.text = "Name: \(person.name!)"
            self.labelAddress.text = "Address: \(person.address!)"
            self.labelEmail.text = "Email: \(person.email!)"
            self.labelPhone.text = "Phone: \(person.phone!)"
        }
        present(vc, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! InputViewController
        vc.onSaveInfo = { person in
            self.labelName.text = "Name: \(person.name!)"
            self.labelAddress.text = "Address: \(person.address!)"
            self.labelEmail.text = "Email: \(person.email!)"
            self.labelPhone.text = "Phone: \(person.phone!)"
        }
    }
    
}

