//
//  InputViewController.swift
//  Application4
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class InputViewController: BaseViewController {
    
    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editPhone: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        var result = false
        if editName.text!.count == 0 {
            showWarning(warning: "please enter name")
        } else if editAddress.text!.count == 0 {
            showWarning(warning: "please enter address")
        } else if editEmail.text!.count == 0 {
            showWarning(warning: "please enter email")
        } else if editPhone.text!.count == 0 {
            showWarning(warning: "please enter phone")
        } else {
            result = true
        }
        
        return result
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! InformationViewController
        vc.person = Person(
            name: editName.text!,
            address: editAddress.text!,
            email: editEmail.text!,
            phone: editPhone.text!)
    }

}
