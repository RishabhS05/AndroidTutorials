//
//  InformationViewController.swift
//  Application4
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class InformationViewController: BaseViewController {
    var person: Person!
    
    @IBOutlet weak var labelEmail: UILabel!
    @IBOutlet weak var labelPhone: UILabel!
    @IBOutlet weak var labelAddress: UILabel!
    @IBOutlet weak var labelName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelName.text = "Name: \(person.name!)"
        labelAddress.text = "Address: \(person.address!)"
        labelEmail.text = "Email: \(person.email!)"
        labelPhone.text = "Phone: \(person.phone!)"
    }

    @IBAction func onBack() {
        dismiss(animated: true, completion: nil)
    }
}
