//
//  BaseViewController.swift
//  Application4
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
   

    func showWarning(warning: String) {
        let alert = UIAlertController(title: "warning", message: warning, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
