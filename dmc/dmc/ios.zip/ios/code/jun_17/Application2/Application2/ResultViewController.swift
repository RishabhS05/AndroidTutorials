//
//  ResultViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ResultViewController: UIViewController {
    
    var firstName: String!
    var lastName: String!

    @IBOutlet weak var labelLastName: UILabel!
    @IBOutlet weak var labelFirstName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        labelFirstName.text = firstName
        labelLastName.text = lastName
    }
    
    
    @IBAction func onBack() {
        dismiss(animated: true, completion: nil)
    }
    
}
