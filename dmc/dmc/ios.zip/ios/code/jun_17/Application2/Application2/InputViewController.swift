//
//  InputViewController.swift
//  Application2
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class InputViewController: UIViewController {
    
    @IBOutlet weak var editFirstName: UITextField!
    @IBOutlet weak var editLastName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func onSave() {
        if editFirstName.text!.count == 0 {
            let alert = UIAlertController(title: "error", message: "please enter first name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        } else if editLastName.text!.count == 0 {
            let alert = UIAlertController(title: "error", message: "please enter last  name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        } else {
            print("first name: \(editFirstName.text!)")
            print("last name: \(editLastName.text!)")
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "ResultViewController") as! ResultViewController
            vc.firstName = editFirstName.text!
            vc.lastName = editLastName.text!
            present(vc, animated: true, completion: nil)
        }
    }
    
}
