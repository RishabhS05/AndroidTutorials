//
//  main.swift
//  Application7
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

// (Int, Int) ->  Void
func add(p1: Int, p2: Int) {
    print("addition: \(p1 + p2)")
}

// (Int, Int) ->  Void
func subtract(p1: Int, p2: Int) {
    print("subtraction: \(p1 - p2)")
}

let myFunc: ((Int, Int) -> Void) = add

myFunc(10, 20)

