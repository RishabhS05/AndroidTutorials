//
//  ViewController.swift
//  Application1
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var editFirstName: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editLastName: UITextField!
    @IBOutlet weak var labelInfo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func onSave() {
        if editFirstName.text!.count == 0 {
            
            let alert = UIAlertController(title: "error", message: "please enter first name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            
        } else if editLastName.text!.count == 0 {
            
            let alert = UIAlertController(title: "error", message: "please enter last name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            
        } else {
            print("first name: \(editFirstName.text!)")
            print("last name: \(editLastName.text!)")
            print("address: \(editAddress.text!)")
            print("email: \(editEmail.text!)")
            
            var info = ""
            info += "first name: \(editFirstName.text!)\n"
            info += "last name: \(editLastName.text!)\n"
            info += "address: \(editAddress.text!)\n"
            info += "email: \(editEmail.text!)\n"
            
            labelInfo.text = info
        }
    }
    
    @IBAction func onCancel() {
        editFirstName.text = ""
        editLastName.text = ""
        editAddress.text = ""
        editEmail.text = ""
    }
    
}

