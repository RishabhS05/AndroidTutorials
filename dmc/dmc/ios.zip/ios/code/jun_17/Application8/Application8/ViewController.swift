//
//  ViewController.swift
//  Application8
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var segmentedControlGender: UISegmentedControl!
    @IBOutlet weak var imageViewGender: UIImageView!
    
    @IBOutlet weak var switchHungry: UISwitch!
    
    @IBOutlet weak var labelHungry: UILabel!
    
    @IBOutlet weak var labelProgress: UILabel!
    
    @IBOutlet weak var sliderProgress: UISlider!
    
    @IBOutlet weak var stepperQuantities: UIStepper!
    
    @IBOutlet weak var labelQuantities: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func onQuantityChange() {
        labelQuantities.text = "\(Int(stepperQuantities.value))"
    }
    
    
    @IBAction func onProgressChange() {
        let progress: Int = Int(sliderProgress!.value)
        labelProgress.text = "\(progress)%"
    }
    
    @IBAction func onHungryStatusChange() {
        labelHungry.text = switchHungry.isOn ? "Yes" : "No"
        
//        if switchHungry.isOn == true {
//            labelHungry.text = "Yes"
//        } else {
//            labelHungry.text = "No"
//        }
    }
    
    // ValueChanged
    @IBAction func onGenderChange() {
        var imageName = ""
        if segmentedControlGender.selectedSegmentIndex == 0 {
            print("Gender: Male")
            imageName = "male"
        } else if segmentedControlGender.selectedSegmentIndex == 1 {
            print("Gender: Female")
            imageName = "female"
        } else if segmentedControlGender.selectedSegmentIndex == 2 {
            print("Gender: Not Known")
            imageName = "not-known"
        }
        
        let image = UIImage(named: imageName)
        imageViewGender.image = image
    }
    
    // TouchUpInside
    @IBAction func onSave() {
        print("Name: \(editName.text!)")
        
        if segmentedControlGender.selectedSegmentIndex == 0 {
            print("Gender: Male")
        } else if segmentedControlGender.selectedSegmentIndex == 1 {
            print("Gender: Female")
        } else if segmentedControlGender.selectedSegmentIndex == 2 {
            print("Gender: Not Known")
        }
    }
}

