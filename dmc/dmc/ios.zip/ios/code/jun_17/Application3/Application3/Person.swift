//
//  Person.swift
//  Application3
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Person {
    var name: String!
    var address: String!
    var email: String!
    var phone: String!
    
    init(name: String, address: String, email: String, phone: String) {
        self.name = name
        self.address = address
        self.email = email
        self.phone = phone
    }
}
