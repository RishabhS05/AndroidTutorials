//
//  InputViewController.swift
//  Application3
//
//  Created by Amit Kulkarni on 17/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import UIKit

class InputViewController: BaseViewController {

    @IBOutlet weak var editName: UITextField!
    @IBOutlet weak var editAddress: UITextField!
    @IBOutlet weak var editEmail: UITextField!
    @IBOutlet weak var editPhone: UITextField!
    
    @IBOutlet weak var labelNameError: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func onSave() {
        if editName.text!.count == 0 {
//            showWarning(warning: "please enter name")
            labelNameError.isHidden = false
        } else if editAddress.text!.count == 0 {
            showWarning(warning: "please enter address")
        } else if editEmail.text!.count == 0 {
            showWarning(warning: "please enter email")
        } else if editPhone.text!.count == 0 {
            showWarning(warning: "please enter phone")
        } else {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "InformationViewController") as! InformationViewController
            
//            vc.name = editName.text!
//            vc.address = editAddress.text!
//            vc.email = editEmail.text!
//            vc.phone = editPhone.text!
            
            
            vc.person = Person(
                name: editName.text!,
                address: editAddress.text!,
                email: editEmail.text!,
                phone: editPhone.text!)
            
            present(vc, animated: true, completion: nil)
        }
    }
}
