//
//  main.swift
//  Application7
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Person {
    var firstName: String?
    var lastName: String?
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    var fullName: String? {
        willSet(newFullName) {
            print("inside will set: \(newFullName!)")
            if let newFullName = newFullName {
                let names = newFullName.split(separator: " ")
                firstName = String(names[0])
                lastName = String(names[1])
            }
        }
        
        didSet {
            print("inside did set: \(firstName!)")
        }
    }
    
}

var p1 = Person(firstName: "bill", lastName: "gates")
print("firstName: \(p1.firstName!)")
p1.fullName = "steve balmer"
print("firstName: \(p1.firstName!)")
