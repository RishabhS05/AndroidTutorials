//
//  main.swift
//  Application8
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class MediaItem {
    var name: String?
    var year: Int?
    
    init(name: String, year: Int) {
        self.name = name
        self.year = year
    }
    
    func printMediaItem() {
        print("name: \(name!), year: \(year!)")
    }
}

class Song: MediaItem {
    var singer: String?
    
    init(name: String, year: Int, singer: String) {
        super.init(name: name, year: year)
        self.singer = singer
    }
    
    func printSong() {
        print("name: \(name!), year: \(year!), singer: \(singer!)")
    }
}

class Movie: MediaItem {
    var actor: String?
    
    init(name: String, year: Int, actor: String) {
        super.init(name: name, year: year)
        self.actor = actor
    }
    
    func printMovie() {
        print("name: \(name!), year: \(year!), actor: \(actor!)")
    }
}

// polymorphism
//let item1: MediaItem = MediaItem()
//let item2: MediaItem = Song()
//let item3: MediaItem = Movie()
//let song1: Song = Song()
//let movie1: Movie = Movie()

//print("item1 is MediaItem = \(item1 is MediaItem)")
//print("item2 is MediaItem = \(item2 is MediaItem)")
//print("item3 is MediaItem = \(item3 is MediaItem)")

let mediaItems: [MediaItem] = [
    MediaItem(name: "item 1", year: 2010),
    Song(name: "song 1", year: 2019, singer: "singer 1"),
    Movie(name: "movie 1", year: 2017, actor: "actor 1")
]

//print(mediaItems)

// String item = (String) Song;

//for item in mediaItems {
//    if let movieItem = item as? Movie {
//        movieItem.printMovie()
//    } else if let songItem = item as? Song {
//        songItem.printSong()
//    } else if let mediaItem = item as? MediaItem {
//        mediaItem.printMediaItem()
//    }
//}

let item1: MediaItem =  MediaItem(name: "item 1", year: 2010)
let item2: MediaItem = Song(name: "song 1", year: 2019, singer: "singer 1")
let item3: MediaItem = Movie(name: "movie 1", year: 2017, actor: "actor 1")

print("item1 as? MediaItem = \(item1 as! MediaItem)")
print("item1 as? Song = \(item1 as? Song)")
print("item1 as? Movie = \(item1 as? Movie)")

print("item2 as? MediaItem = \(item2 as! MediaItem)")
print("item2 as? Song = \(item2 as? Song)")
print("item2 as? Movie = \(item2 as? Movie)")

print("item3 as? MediaItem = \(item3 as! MediaItem)")
print("item3 as? Song = \(item3 as? Song)")
print("item3 as? Movie = \(item3 as? Movie)")

