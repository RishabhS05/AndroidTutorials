//
//  main.swift
//  Application4
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Person {
    var name: String?
    var address: String?
    var age: Int?
    
    init() {
        print("person init")
        name = ""
        address = ""
        age = 0
    }
    
    init(name: String, address: String, age: Int) {
        self.name = name
        self.address = address
        self.age = age
    }
    
    func printDetails() {
        print("name: \(name!)")
        print("address: \(address!)")
        print("age: \(age!)")
    }
}

class Player : Person {
    var team: String?
    
    override init() {
        super.init()
        print("player init")
    }
    
    init(name: String, address: String, age: Int, team: String) {
        super.init(name: name, address: address, age: age)
        self.team = team
    }
    
    override func printDetails() {
        super.printDetails()
        print("team: \(team!)")
    }
}

let person1 = Person(name: "person1", address: "Pune", age: 30)
person1.printDetails()

let player1 = Player(name: "player1", address: "mumbai", age: 40, team: "India")
player1.printDetails()

