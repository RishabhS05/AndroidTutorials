//
//  main.swift
//  Application2
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

struct Rectangle {
    // stored properties
    var height = 0
    var width = 0
    
    // compound property
    var area: Int {
        get {
            return height * width
        }
    }
    
//    func area() -> Int {
//        return height * width
//    }
}

let r1 = Rectangle(height: 10, width: 30)
//print("area of rectange: \(r1.area())")
print("area of rectange: \(r1.area)")


struct Person {
    // stored
    var firstName: String
    var lastName: String
    
    // computed
    var fullName: String {
        get { return "\(firstName) \(lastName)" }
        set {
            print("new value = \(newValue)")
            let names = newValue.split(separator: " ")
            firstName = String(names[0])
            lastName = String(names[1])
        }
    }
}

var p1 = Person(firstName: "bill", lastName: "gates")
print("full name: \(p1.fullName)")
//p1.firstName = "steve"
//p1.lastName = "jobs"
p1.fullName = "steve jobs"
print("full name: \(p1.fullName)")
