//
//  main.swift
//  Application5
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Person {
    var name: String?
    var address: String?
    var age: Int?
    
    // computed property
    var details: String {
        get { return "Name: \(name!), Address: \(address!), Age: \(age!)" }
    }

    init(name: String, address: String, age: Int) {
        self.name = name
        self.address = address
        self.age = age
    }
}

class Player: Person {
    var team: String?
    
    override var details: String {
        get { return "Name: \(name!), Address: \(address!), Age: \(age!), Team Name: \(team!)" }
    }
    
    init(name: String, address: String, age: Int, team: String) {
        super.init(name: name, address: address, age: age)
        self.team = team
    }
}

let person1 = Person(name: "person1", address: "Pune", age: 30)
print("details: \(person1.details)")

let player1  = Player(name: "player1", address: "mumbai", age: 45, team: "India")
print("details: \(player1.details)")
