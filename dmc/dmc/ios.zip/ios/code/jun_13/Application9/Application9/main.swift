//
//  main.swift
//  Application9
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func swapInt(p1: inout Int, p2: inout Int) {
    let temp = p1
    p1 = p2
    p2 = temp
}

func swapString(p1: inout String, p2: inout String) {
    let temp = p1
    p1 = p2
    p2 = temp
}

// generic function
func swap<T>(p1: inout T, p2: inout T) {
    let temp = p1
    p1 = p2
    p2 = temp
}

var n1 = 20, n2 = 30
print("before n1: \(n1), n2: \(n2)")
//swapInt(p1: &n1, p2: &n2)
swap(&n1, &n2)
print("after n1: \(n1), n2: \(n2)")


var str1 = "string 1", str2 = "string 2"
print("before str1: \(str1), str2: \(str2)")
//swapString(p1: &str1, p2: &str2)
swap(&str1, &str2)
print("after str1: \(str1), str2: \(str2)")
