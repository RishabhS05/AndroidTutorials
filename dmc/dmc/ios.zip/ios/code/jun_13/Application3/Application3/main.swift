//
//  main.swift
//  Application3
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Point {
    var x: Int = 0
    var y: Int = 0
}

// reference is mutable
// object is mutable
var point1 = Point()
point1.x = 20
point1.y = 10

var point3 = Point()
point1 = point3

// reference is immutable
// object is mutable
let point2 = Point()
point2.x = 30
point2.y = 50

// not possible
//point2 = point3

// possible
point2.x = point3.x
point2.y = point3.y

class Person {
    var name: String?
    var address: String?
    var age: Int?
    
    // default
    init() {
        print("iniside init")
        name = ""
        address = ""
        age = 0
    }
    
    // custom
    init(name: String, address: String, age: Int) {
        print("iniside init")
        self.name = name
        self.address = address
        self.age = age
    }
    
    // facilator
    func printDetails() {
        print("name: \(name!)")
        print("address: \(address!)")
        print("age: \(age!)")
    }
    
    var details: String {
        get {
            return "Name: \(name!), Address: \(address!), Age: \(age!)"
        }
    }
    
    deinit {
        print("inside deinit")
    }
}

let person1 = Person()
//person1.name = "person1"
//person1.address = "Pune"
//person1.age = 30
person1.printDetails()
print(person1.details)

let person2 = Person(name: "person2", address: "Karad", age: 40)
person2.printDetails()
print(person2.details)
