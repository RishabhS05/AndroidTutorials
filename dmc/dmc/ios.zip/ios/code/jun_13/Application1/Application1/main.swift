//
//  main.swift
//  Application1
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

struct Point {
    // properties
    var x: Int
    var y: Int
}

// mutable
var point1 = Point(x: 10, y: 30)
point1.x = 100
point1.y = 200

// immutable
let point2 = Point(x: 40, y: 50)
//point2.x = 60
//point2.y = 70

// has-a relationship
struct Rectangle {
    var topLeft: Point
    var topRight: Point
    var bottomLeft: Point
    var bottomRight: Point
}

var rectangle = Rectangle(
    topLeft: Point(x: 10, y: 10),
    topRight: Point(x: 100, y: 10),
    bottomLeft: Point(x: 10, y: 100),
    bottomRight: Point(x: 100, y: 100))
