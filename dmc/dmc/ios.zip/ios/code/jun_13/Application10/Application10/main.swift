//
//  main.swift
//  Application10
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Stack<T> {
    var top: Int = -1
    var array: [T] = []
    
    func push(value: T) {
        array.append(value)
        top += 1
    }
    
    func pop() {
        if top == -1 {
            print("stack is empty")
        } else {
            let value = array[top]
            top -= 1
            print("popped value: \(value)")
        }
    }
}

let stack = Stack<Int>()
stack.push(value: 10)
stack.push(value: 20)
stack.pop()
stack.pop()
stack.pop()

let stack2 = Stack<String>()
stack2.push(value: "string 1")
stack2.push(value: "string 2")
stack2.push(value: "string 3")

stack2.pop()
stack2.pop()
stack2.pop()
stack2.pop()
stack2.pop()
stack2.pop()
stack2.pop()
stack2.pop()
