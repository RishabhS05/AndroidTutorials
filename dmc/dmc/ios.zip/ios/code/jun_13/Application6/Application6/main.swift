//
//  main.swift
//  Application6
//
//  Created by Amit Kulkarni on 13/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

class Downloader {
    init() {
        print("iniside downloader init")
    }
    
    func download() {
        print("downloading....")
    }
}

class MyFile {
    var name: String?
    var type: String?
    
    lazy var downloader = Downloader()
    
    func downloadFile() {
        print("My file will get downloaded")
        downloader.download()
    }
    
    func test() {
        print("inside test  method")
    }
}

let f1 = MyFile()
f1.downloadFile()
f1.test()
