//
//  main.swift
//  Application3
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

var num: Int? = nil
print("num = \(num), type: \(type(of: num))")

let num2 = num
print("num2 = \(num2), type: \(type(of: num2))")

if let num3 = num {
    print("num3 = \(num3), type: \(type(of: num3))")
}


let num4 = num ?? 1
print("num4 = \(num4), type = \(type(of: num4))")


