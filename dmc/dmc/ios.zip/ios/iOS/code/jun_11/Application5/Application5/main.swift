//
//  main.swift
//  Application5
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

/*
 
 // Java
 void myFunction() {
 }
 
 // param1: name
 //
 //
 void myFunction5(String n, String a, int g) {
    //
 }
 
 myFunction5()
 
 // typescript
 function myFunction1() : void {
 }
 
 function myFunction2(name: string) : void {
 }
 
 myFunction2("steve");
 
*/


// declaration
// parameterless function
func myFunction1() -> Void {
    print("inside myFunction")
}

//myFunction1()


// parameterized function
func myFunction2(name: String) {
    print("name: \(name)")
}

//myFunction2(name: "steve")

func myFunction3(number n: Int) {
    print("inside myFunction3")
    print("n = \(n)")
}

//myFunction3(number: 10)

func myFunction4(number: Int) {
    print("inside myFunction3")
    print("number = \(number)")
}

//myFunction4(number: 10)


func myFunction5(personName name: String, personAddress address: String, personAge age: Int) {
    print("name = \(name)")
    print("address = \(address)")
    print("age = \(age)")
}

//myFunction5(personName: "person1", personAddress: "Pune", personAge: 40)


// myFunction6:number
func myFunction6(number n: Int) {
    print("1 n = \(n)")
}


// myFunction6:number2
func myFunction6(number2 n: Int) {
    print("2 n = \(n)")
}

myFunction6(number: 10)
myFunction6(number2: 30)
