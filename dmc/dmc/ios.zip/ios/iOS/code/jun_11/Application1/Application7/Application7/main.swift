//
//  main.swift
//  Application7
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

func function1() {
    // mutable
    // ArrayList<Integer> numbers = new ArrayList<>();
    // numbers.add(1);
    var numbers = [10, 20, 30, 40, 50]
    
    // numbers.size()
    print("count: \(numbers.count)")
    
    // append a value
    // numbers.add(60);
    numbers.append(60)
    print(numbers)

    // numbers.remove(1)
    numbers.remove(at: 1)
    print(numbers)
    
    // for..each
    for value in numbers {
        print(value)
    }
    
    // numbers.clear();
    numbers.removeAll()
    print(numbers)

}

function1();

func function2() {
    // immutable
    // int numbers[] = [1, 2, 3, 4, 5];
    let numbers = [1, 2, 3, 4, 5]
    
    // numbers.length()
    print("count: \(numbers.count)")
    
    // numbers.append(6)
    // numbers.remove(at: 1)
    // numbers.removeAll()
    
    // traditional for loop
    for index in 0..<numbers.count {
        print(numbers[index])
    }
}

function2()
