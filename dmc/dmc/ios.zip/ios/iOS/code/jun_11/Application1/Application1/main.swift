//
//  main.swift
//  Application1
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

// mutable
var num = 10
print("num = \(num)")
print("type = \(type(of: num))")

num = 100
print("num = \(num)")


// immutable
let name = "steve"
print("type = \(type(of: name))")
// name = "bill"

let num2: Int = 10
print("num2 = \(num2)")
print("type = \(type(of: num2))")


let number = 10
print("number = \(number), type = \(type(of: number))")

let salary = 4.5
print("salary = \(salary), type = \(type(of: salary))")

let canVote = true
print("canVote = \(canVote), type = \(type(of: canVote))")

let fullName = "steve jobs"
print("fullName = \(fullName), type = \(type(of: fullName))")

let maxInt = Int.max
print("maxInt = \(maxInt)")


let minInt = Int.min
print("minInt = \(minInt)")

/*
 var num5 = 10; // number
 num5 = "test"; // string
*/


// Int
var myVar = 10
print("myVar = \(myVar), type = \(type(of: myVar))")

// not possible: type safety
// myVar = "test"

myVar = 100

// typedef MyInt int
typealias MyInt = Int

let myVar2: MyInt = 10


