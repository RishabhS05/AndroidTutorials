//
//  main.swift
//  Application6
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

/*
 
 function add1(p1, p2) {
    const result = p1 + p2;
 }
 
 add1(10, 20);
 add1(10, "test");
 
 function add2(p1: number, p2: number) {
    const result = p1 + p2;
 }
 
 add2(10, 20);
 // add2(10, "test"); // error
 
*/

func add(number1 p1: Int, number2 p2: Int = 40) {
    let result = p1 + p2
    print("addition : \(result)")
}

add(number1: 10, number2: 20)
//add(number1: 30)


func swap(p1: inout Int, p2: inout Int) {
    let temp = p1
    p1 = p2
    p2 = temp
}

var v1 = 20
var v2 = 30
print("before v1: \(v1), v2: \(v2)")
swap(&v1, &v2)
print("after v1: \(v1), v2: \(v2)")



