//
//  main.swift
//  Application4
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

/////// /////// /////// /////// /////// ///////
/***************** Range operators *****************/
/////// /////// /////// /////// /////// ///////

/*
    for (int index = 0; index <= 10; index++) {
        SOP(index)
    }
 */

for index in 0...10 {
    print(index)
}


/*
 for (int index = 0; index < 10; index++) {
    SOP(index)
 }
 */

for index in 0..<10 {
    print(index)
}

