//
//  main.swift
//  Application2
//
//  Created by Amit Kulkarni on 11/06/19.
//  Copyright © 2019 Sunbeam. All rights reserved.
//

import Foundation

var num: Int = 10
print("num = \(num), type = \(type(of: num))")

var num2: Int? = 10
print("num2 = \(num2), type = \(type(of: num2))")

var name: String = "steve"
print("name = \(name), type = \(type(of: name))")

var name2: String? = "steve"
print("name2 = \(name2), type = \(type(of: name2))")


if num == num2 {
    print("equal")
} else {
    print("not equal")
}

//if num2 == name2 {
//    print("equal")
//} else {
//    print("not equal")
//}

var num3: Int? = 10
print("num3 = \(num3), type = \(type(of: num3))")

var num4 = num3
print("num4 = \(num4), type = \(type(of: num4))")

var num5 = num3!
print("num5 = \(num5), type = \(type(of: num5))")


var name3: String? = "test"
print("name3 = \(name3), type = \(type(of: name3))")
print("name3 = \(name3!), type = \(type(of: name3!))")

var name4 = name3
print("name4 = \(name4), type = \(type(of: name4))")

var name5 = name3!
print("name5 = \(name5), type = \(type(of: name5))")


var num6: Int? = nil
print("num6 = \(num6), type = \(type(of: num6))")
//print("num6 = \(num6!), type = \(type(of: num6!))")


var num7: Int? = nil
if num7 != nil {
    print("num7: \(num7!)")
} else {
    print("num7 is nil")
}

var name6: String? = "test"
if name6 != nil {
    let name61 = name6!
    print("name61 : \(name61), type: \(type(of: name61))")
}

var name7: String? = "test"
if let name71 = name7 {
    print("name71 : \(name71), type: \(type(of: name71))")
}

/*
 String name;
*/

/*
 var name: String
 
 var name2: String?
*/

var name8: String? = "test"
// check against nil and create a new unwrapped variable only
// when  the name8 is not nil
if let name8 = name8 {
    print("name8 : \(name8), type: \(type(of: name8))")
} else {
    print("name 8 is nil")
}


enum Day {
    case Monday
    case Tuesday
    case Wednesday
}

let day1: Day = Day.Monday
let day2: Day = .Wednesday

enum Color {
    case Red, Green, Blue
}

let red = Color.Red
let green: Color = .Green
